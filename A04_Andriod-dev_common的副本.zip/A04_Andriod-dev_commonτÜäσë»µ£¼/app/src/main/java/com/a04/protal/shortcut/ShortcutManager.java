package com.a04.protal.shortcut;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ShortcutInfo;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;

import com.a04.protal.R;
import com.a04.protal.account.drawal.DrawalActivity;
import com.a04.protal.recharge.activity.RechargeActivity;
import com.a04.protal.sign.LoginActivity;
import com.a04.protal.utils.GameUtils;
import com.a04.protal.utils.StatisticsAGQJClickFrom;
import com.a04.protal.utils.UserHelper;

import java.util.ArrayList;
import java.util.List;

import static com.a04.protal.shortcut.ShortcutCons.SHORTCUT;
import static com.a04.protal.shortcut.ShortcutCons.SHORTCUT_AGIN;
import static com.a04.protal.shortcut.ShortcutCons.SHORTCUT_AGQJ;
import static com.a04.protal.shortcut.ShortcutCons.SHORTCUT_DEPOSIT;
import static com.a04.protal.shortcut.ShortcutCons.SHORTCUT_WITHDRAW;

/**
 * 创建时间：2019/12/10
 * 方法编写人：Fickle
 * 功能描述：
 */
public enum ShortcutManager {
    INSTANT;

    private List<ShortcutInfo> infos;
    android.content.pm.ShortcutManager mShortcutManager;
    String[] strings = new String[]{"存款", "AG旗舰厅", "AG国际厅", "取款"};

    /**
     * 注册
     * @param context
     */
    public void setupShortcuts(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1) {
            mShortcutManager = context.getSystemService(android.content.pm.ShortcutManager.class);
            if (mShortcutManager.getDynamicShortcuts()==null||mShortcutManager.getDynamicShortcuts().size()!=strings.length) {
                getShortcutsList(context);
                mShortcutManager.setDynamicShortcuts(infos);
            }
        }
    }

    /**
     * @param context
     */
    public void update(Context context){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1) {
            getShortcutsList(context);
            mShortcutManager.updateShortcuts(infos);
        }
    }

    public boolean isShortcut(Intent intent){
        if (intent == null)
            return false;
        String shortcut = intent.getStringExtra(SHORTCUT);
        if (TextUtils.isEmpty(shortcut))
            return false;
        return true;
    }

    public boolean shortcut(AppCompatActivity activity, Intent intent){
        if (intent == null)
            return false;
        String shortcut = intent.getStringExtra(SHORTCUT);
        if (TextUtils.isEmpty(shortcut))
            return false;
        switch (shortcut){
            case SHORTCUT_AGQJ:
                GameUtils.INSTANT.toAGQJ(activity, false, StatisticsAGQJClickFrom.home);
                return true;
            case SHORTCUT_AGIN:
                GameUtils.INSTANT.toAGIN(activity);
                return true;
            case SHORTCUT_WITHDRAW:
                if (checkLogin(activity)) {
                    activity.startActivity(new Intent(activity, DrawalActivity.class));
                }
                break;
            case SHORTCUT_DEPOSIT:
                if (checkLogin(activity)) {
                    activity.startActivity(new Intent(activity, RechargeActivity.class));
                }
                break;
        }

        return false;
    }

    private boolean checkLogin(Activity activity) {
        boolean login = UserHelper.INSTANT.isLogin();
        if (!login) {
            Intent intent = new Intent(activity, LoginActivity.class);
            activity.startActivity(intent);
        }
        return login;
    }


    private List<ShortcutInfo> getShortcutsList(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1) {
            infos = new ArrayList<>();
            ShortcutIntent shortcutIntent=new ShortcutIntent();
            for (int i = 0; i < strings.length; i++) {
                switch (i) {
                    case 0:
                        infos.add(getShortcutInfo(context, shortcutIntent.getDepositIntent(context), strings[i], R.drawable.shortcut_deposit, i));
                        break;
                    case 1:
                        infos.add(getShortcutInfo(context, shortcutIntent.getMainAGQJIntent(context), strings[i], R.drawable.shortcut_agqj, i));
                        break;
                    case 2:
                        infos.add(getShortcutInfo(context, shortcutIntent.getMainAGINIntent(context), strings[i], R.drawable.shortcut_agin, i));
                        break;
                    case 3:
                        infos.add(getShortcutInfo(context, shortcutIntent.getWithdrawIntent(context), strings[i], R.drawable.shortcut_withdraw, i));
                        break;
                }
            }
        }
        return infos;
    }

    private ShortcutInfo getShortcutInfo(Context context, Intent[] intent, String name, int imageId, int id) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1) {
            ShortcutInfo info = new ShortcutInfo.Builder(context, "id" + id)
                    .setShortLabel(name)
                    .setLongLabel(name)
                    .setIcon(Icon.createWithResource(context, imageId))
                    .setIntents(intent)
                    .build();
            return info;
        }
        return null;
    }

}
