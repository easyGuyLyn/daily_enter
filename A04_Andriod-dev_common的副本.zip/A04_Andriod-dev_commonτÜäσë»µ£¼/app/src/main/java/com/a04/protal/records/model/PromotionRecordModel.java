package com.a04.protal.records.model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class PromotionRecordModel implements Serializable {


    /**
     * balance : 1000.00
     * betAmount : 0
     * billNo :
     * bonusAmount : 1000.00
     * cashAmount : 0.00
     * isBetEnough : 0
     * isExpired : 0
     * isLoseAll : 0
     * joinTime : 2021-02-25 15:08:16
     * platforms : 026_3,003_3,064_3,010_3,008_3,035_3,043_3,036_3,026_5,064_5,010_5,035_5,043_5,052_5,067_5,094_5,039_5,027_5,070_1,003_1,091_1,092_1,046_1,062_1,031_1,068_1,010_12,004_12,080_12,031_12,078_12
     * prizeDesc : 礼金1000元
     * promotionAmount : 1000.00
     * promotionId : 727792
     * promotionName : 生日礼金
     * releaseBetAmount : 10000.00
     * status : 1
     * surplusAmount : 1000.00
     * unlockType : 1
     */

    @SerializedName("balance")
    private String balance;
    @SerializedName("betAmount")
    private String betAmount;
    @SerializedName("billNo")
    private String billNo;
    @SerializedName("bonusAmount")
    private String bonusAmount;
    @SerializedName("cashAmount")
    private String cashAmount;
    @SerializedName("isBetEnough")
    private String isBetEnough;
    @SerializedName("isExpired")
    private String isExpired;
    @SerializedName("isLoseAll")
    private String isLoseAll;
    @SerializedName("joinTime")
    private String joinTime;
    @SerializedName("platforms")
    private String platforms;
    @SerializedName("prizeDesc")
    private String prizeDesc;
    @SerializedName("promotionAmount")
    private String promotionAmount;
    @SerializedName("promotionId")
    private String promotionId;
    @SerializedName("promotionName")
    private String promotionName;
    @SerializedName("releaseBetAmount")
    private String releaseBetAmount;
    @SerializedName("status")
    private String status;
    @SerializedName("surplusAmount")
    private String surplusAmount;
    @SerializedName("unlockType")
    private String unlockType;

    public String getBalance() {
        return balance;
    }

    public void setBalance(String balance) {
        this.balance = balance;
    }

    public String getBetAmount() {
        return betAmount;
    }

    public void setBetAmount(String betAmount) {
        this.betAmount = betAmount;
    }

    public String getBillNo() {
        return billNo;
    }

    public void setBillNo(String billNo) {
        this.billNo = billNo;
    }

    public String getBonusAmount() {
        return bonusAmount;
    }

    public void setBonusAmount(String bonusAmount) {
        this.bonusAmount = bonusAmount;
    }

    public String getCashAmount() {
        return cashAmount;
    }

    public void setCashAmount(String cashAmount) {
        this.cashAmount = cashAmount;
    }

    public String getIsBetEnough() {
        return isBetEnough;
    }

    public void setIsBetEnough(String isBetEnough) {
        this.isBetEnough = isBetEnough;
    }

    public String getIsExpired() {
        return isExpired;
    }

    public void setIsExpired(String isExpired) {
        this.isExpired = isExpired;
    }

    public String getIsLoseAll() {
        return isLoseAll;
    }

    public void setIsLoseAll(String isLoseAll) {
        this.isLoseAll = isLoseAll;
    }

    public String getJoinTime() {
        return joinTime;
    }

    public void setJoinTime(String joinTime) {
        this.joinTime = joinTime;
    }

    public String getPlatforms() {
        return platforms;
    }

    public void setPlatforms(String platforms) {
        this.platforms = platforms;
    }

    public String getPrizeDesc() {
        return prizeDesc;
    }

    public void setPrizeDesc(String prizeDesc) {
        this.prizeDesc = prizeDesc;
    }

    public String getPromotionAmount() {
        return promotionAmount;
    }

    public void setPromotionAmount(String promotionAmount) {
        this.promotionAmount = promotionAmount;
    }

    public String getPromotionId() {
        return promotionId;
    }

    public void setPromotionId(String promotionId) {
        this.promotionId = promotionId;
    }

    public String getPromotionName() {
        return promotionName;
    }

    public void setPromotionName(String promotionName) {
        this.promotionName = promotionName;
    }

    public String getReleaseBetAmount() {
        return releaseBetAmount;
    }

    public void setReleaseBetAmount(String releaseBetAmount) {
        this.releaseBetAmount = releaseBetAmount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getSurplusAmount() {
        return surplusAmount;
    }

    public void setSurplusAmount(String surplusAmount) {
        this.surplusAmount = surplusAmount;
    }

    public String getUnlockType() {
        return unlockType;
    }

    public void setUnlockType(String unlockType) {
        this.unlockType = unlockType;
    }
}
