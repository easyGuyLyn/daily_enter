package com.a04.protal.upgrade;

import android.support.v4.app.FragmentActivity;
import android.text.TextUtils;
import android.util.Log;

import com.a04.protal.R;
import com.a04.protal.dialog.HintDialog;
import com.a04.protal.utils.Cons;
import com.a04.protal.utils.HomeDialogHelper;
import com.in.autoupdate.AbstractUpdateDialog;
import com.in.autoupdate.UpgradePlugin;
import com.in.autoupdate.listeners.UpgradeCheckedListener;
import com.in.autoupdate.models.AutoUpdateModel;
import com.in.cache.CacheManager;
import com.in.hybrid.utils.CommonUtils;

import java.lang.ref.WeakReference;

/**
 * Author:Javan.W
 * Time:2018/12/13
 * Description:This is UpgradeUtil
 */
public class UpgradeUtil {
    private static WeakReference<FragmentActivity> activityWeakReference;
    private static UpgradeCheckedListener upgradeCheckedListener = new UpgradeCheckedListener() {
        @Override
        public AbstractUpdateDialog providerUpdateDialog() {
            HomeDialogHelper.getInstance().setUpdateShowing(true);
            return new UpgradeDialog();
        }

        @Override
        public void onCheckFinish(AutoUpdateModel autoUpdateModel) {
        }

        @Override
        public boolean onCheckNoUpdate() {
            if (activityWeakReference != null && activityWeakReference.get() != null && !activityWeakReference.get().isDestroyed()) {

                HintDialog dialog = new HintDialog();
                dialog.setContent("您当前已是最新版本　" + CommonUtils.getVersionName(activityWeakReference.get())).setButton("确定"). setCancellable(false);
                dialog.show(activityWeakReference.get().getSupportFragmentManager(), "newest_version");
            }
            return true;
        }
    };

    public static void autoUpgrade(FragmentActivity context) {
        Log.d("UpgradeUtil", "autoUpgrade executed!");
        activityWeakReference = new WeakReference<>(context);
        UpgradePlugin.INSTANT.setOnUpgradeCheckedListener(upgradeCheckedListener);
        UpgradePlugin.INSTANT.autoUpdate(context, R.mipmap.logo);
        updateCheckTime();
    }

    public static void checkUpdate(FragmentActivity context){
        activityWeakReference = new WeakReference<>(context);
        UpgradePlugin.INSTANT.checkUpdate(context, R.mipmap.logo);
        updateCheckTime();
    }

    //记录检查更新的TimeStamp
    public static void updateCheckTime() {
        CacheManager.get().put(Cons.LAST_CHECK_AUTO_UPDATE_TIME, Long.toString(System.currentTimeMillis()));
    }

    //目前針對四個主頁及存取款頁進入時會檢查，超過一小時就去詢問是否有強更
    public static void needToCheckUpgrade(FragmentActivity context) {
        boolean needToCheck = false;
        String lastTimeStr = CacheManager.get().getString(Cons.LAST_CHECK_AUTO_UPDATE_TIME);
        if(TextUtils.isEmpty(lastTimeStr)) autoUpgrade(context);
        try {
            long lastTime = Long.parseLong(lastTimeStr);
            long currentTime = System.currentTimeMillis();
            if(currentTime - lastTime > 1000 * 60 * 60) {
                autoUpgrade(context);
            }
        }catch (NumberFormatException e) {
            e.printStackTrace();
            autoUpgrade(context);
        }
    }

}
