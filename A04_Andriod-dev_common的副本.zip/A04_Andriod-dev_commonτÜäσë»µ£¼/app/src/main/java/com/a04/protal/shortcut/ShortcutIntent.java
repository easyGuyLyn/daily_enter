package com.a04.protal.shortcut;

import android.content.Context;
import android.content.Intent;

import com.a04.protal.SplashActivity;
import com.a04.protal.activitys.main.MainActivity;
import static android.provider.UserDictionary.Words.SHORTCUT;
import static com.a04.protal.shortcut.ShortcutCons.SHORTCUT_AGIN;
import static com.a04.protal.shortcut.ShortcutCons.SHORTCUT_AGQJ;
import static com.a04.protal.shortcut.ShortcutCons.SHORTCUT_DEPOSIT;
import static com.a04.protal.shortcut.ShortcutCons.SHORTCUT_WITHDRAW;

/**
 * 创建时间：2019/12/10
 * 方法编写人：Fickle
 * 功能描述：
 */
public class ShortcutIntent {

    //存款
    public Intent[] getDepositIntent(Context context) {
        return getIntent(context,SHORTCUT_DEPOSIT);
    }

    //提现
    public Intent[] getWithdrawIntent(Context context) {
        return getIntent(context,SHORTCUT_WITHDRAW);
    }

    //AGQJ
    public Intent[] getMainAGQJIntent(Context context){
        return getIntent(context,SHORTCUT_AGQJ);
    }

    //AGIN
    public Intent[] getMainAGINIntent(Context context){
        return getIntent(context,SHORTCUT_AGIN);
    }

    private Intent[] getIntent(Context context,String type){
        Intent[] intents;
        Intent intentLaunch = context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());
        intentLaunch.setAction(Intent.ACTION_MAIN);

        Intent intent = new Intent(context, SplashActivity.class);
        intent.putExtra(SHORTCUT,type);
        intent.setAction(Intent.ACTION_VIEW);
        intents =new Intent[]{intentLaunch,intent};
        return intents;
    }
}
