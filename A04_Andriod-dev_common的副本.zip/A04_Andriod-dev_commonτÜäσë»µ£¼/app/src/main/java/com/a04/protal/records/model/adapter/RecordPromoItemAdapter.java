package com.a04.protal.records.model.adapter;

import android.content.Context;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.a04.protal.R;
import com.a04.protal.records.model.PromotionRecordModel;
import com.a04.protal.utils.EventHelper;
import com.a04.protal.utils.UserHelper;
import com.a04.protal.utils.Util;

import java.util.ArrayList;
import java.util.List;

public class RecordPromoItemAdapter extends RecyclerView.Adapter<RecordPromoItemAdapter.Holder> {

    private static final int TYPE_HEADER = 0;
    private static final int TYPE_ITEM = 1;
    private static final int TYPE_FOOTER = 2;


    public enum DayRangeType {

        TODAY(0), BEFORE_7DAYS(1), BEFORE_15DAYS(2), BEFORE_30DAYS(3);

        private int index;

        DayRangeType(int index) {
            this.index = index;
        }

        public int getValue() {
            return this.index;
        }
    }

    private List<PromotionRecordModel> mPromoList;
    private Context mContext;
    private boolean isUsdt = UserHelper.INSTANT.isUsdtMode();

    public RecordPromoItemAdapter(Context context) {
        this.mContext = context;
    }

    @Override
    @NonNull
    public Holder onCreateViewHolder (@NonNull ViewGroup parent, int viewType) {
        if(viewType == TYPE_HEADER) {
            View v = LayoutInflater.from (mContext).inflate (R.layout.item_records_header, parent, false);
            return new RecordHeaderViewHolder(v);
        } else if(viewType == TYPE_FOOTER) {
            View v = LayoutInflater.from (mContext).inflate (R.layout.item_records_footer, parent, false);
            return new RecordFooterViewHolder(v);
        } else {
            View v = LayoutInflater.from (mContext).inflate (R.layout.item_records, parent, false);
            return new RecordItemViewHolder(v);
        }
    }

    @Override
    public void onBindViewHolder (@NonNull Holder holder, int position) {

        if(holder instanceof RecordItemViewHolder) {
            if(Util.isListEmpty(mPromoList)) return;
            RecordItemViewHolder itemHolder = (RecordItemViewHolder) holder;
            setPromoItem(itemHolder, mPromoList.get(position - 1));
        }
    }

    @Override
    public int getItemViewType (int position) {
        if(position == 0) {
            return TYPE_HEADER;
        } else if(isPositionFooter (position)) {
            return TYPE_FOOTER;
        }
        return TYPE_ITEM;
    }

    @Override
    public int getItemCount () {
        return mPromoList.size() + 2;
    }

    private boolean isPositionFooter (int position) {
        return position == mPromoList.size() + 1;
    }

    private void setPromoItem(RecordItemViewHolder itemHolder, PromotionRecordModel promoModel) {
        EventHelper.setVisibility(View.VISIBLE, itemHolder.tvAmount, itemHolder.tvAccountInfo);
        EventHelper.setVisibility(View.GONE, itemHolder.tvTxnHurry, itemHolder.layoutTxn, itemHolder.layoutExchangeTop, itemHolder.layoutExchangeBottom);

        itemHolder.tvAmount.setText(Util.formatDecimalPoint2(promoModel.getBonusAmount()) + (isUsdt? "USDT" : "元") );
        itemHolder.tvUpdateTime.setText(null == promoModel.getJoinTime()? "" : promoModel.getJoinTime());
        itemHolder.tvAccountInfo.setText(promoModel.getPromotionName());
    }

    private void setPromoStatus(RecordItemViewHolder viewHolder, int flag) {
        switch (flag) {
            case 1:
                viewHolder.tvTxnStatus.setText("可使用");
                viewHolder.tvTxnStatus.setTextColor(Color.parseColor("#e7b145"));
                break;
            case 2:
                viewHolder.tvTxnStatus.setText("使用中");
                viewHolder.tvTxnStatus.setTextColor(Color.parseColor("#6dd400"));
                break;
            case 3:
                viewHolder.tvTxnStatus.setText("待确认");
                viewHolder.tvTxnStatus.setTextColor(Color.parseColor("#e7b145"));
                break;
            case 4:
                viewHolder.tvTxnStatus.setText("已结束");
                viewHolder.tvTxnStatus.setTextColor(Color.parseColor("#ff3636"));
                break;
            case 5:
                viewHolder.tvTxnStatus.setText("待审核");
                viewHolder.tvTxnStatus.setTextColor(Color.parseColor("#e7b145"));
                break;
            case 6:
                viewHolder.tvTxnStatus.setText("审核拒绝");
                viewHolder.tvTxnStatus.setTextColor(Color.parseColor("#e7b145"));
                break;
        }

    }




    public void setList(List<PromotionRecordModel> promoList) {
        if (mPromoList == null) {
            mPromoList = new ArrayList<>();
        }else {
            mPromoList.clear();
        }
        if (mPromoList != null) {
            mPromoList.addAll(promoList);
        }
    }

    class Holder extends RecyclerView.ViewHolder {

        private Holder(View itemView) {
            super(itemView);
        }
    }

    class RecordFooterViewHolder extends Holder {

        public RecordFooterViewHolder(View itemView) {
            super (itemView);
        }
    }

    class RecordHeaderViewHolder extends Holder {

        public RecordHeaderViewHolder(View itemView) {
            super (itemView);
        }
    }

    class RecordItemViewHolder extends Holder {

        TextView tvAmount;
        TextView tvTxnHurry;
        TextView tvUpdateTime;
        TextView tvAccountInfo;
        TextView tvTxnStatus;
        ConstraintLayout layoutTxn;
        TextView tvTxnInfo;
        TextView tvCopyTxnNo;

        LinearLayout layoutExchangeTop;
        LinearLayout layoutExchangeBottom;
        ImageView ivSrcCurrency;
        ImageView ivTrgtCurrency;
        TextView tvExchangeSource;
        TextView tvExchangeTarget;


        public RecordItemViewHolder(View itemView) {
            super (itemView);
            tvAmount = (TextView) itemView.findViewById(R.id.tv_amount);
            tvTxnHurry = (TextView) itemView.findViewById(R.id.tv_txn_hurry);
            tvUpdateTime = (TextView) itemView.findViewById(R.id.tv_update_time);
            tvAccountInfo = (TextView) itemView.findViewById(R.id.tv_account_info);
            tvTxnStatus = (TextView) itemView.findViewById(R.id.tv_txn_status);

            layoutTxn = (ConstraintLayout) itemView.findViewById(R.id.layout_txn);
            tvTxnInfo = (TextView) itemView.findViewById(R.id.tv_txn_info);
            tvCopyTxnNo = (TextView) itemView.findViewById(R.id.tv_copy_txn_no);

            layoutExchangeTop = (LinearLayout) itemView.findViewById(R.id.layout_exchangeTop);
            layoutExchangeBottom = (LinearLayout) itemView.findViewById(R.id.layout_exchange_bottom);
            ivSrcCurrency = (ImageView) itemView.findViewById(R.id.iv_src_currency);
            ivTrgtCurrency = (ImageView) itemView.findViewById(R.id.iv_trgt_currency);
            tvExchangeSource = (TextView) itemView.findViewById(R.id.tv_exchange_source);
            tvExchangeTarget = (TextView) itemView.findViewById(R.id.tv_exchange_target);


        }
    }

}

