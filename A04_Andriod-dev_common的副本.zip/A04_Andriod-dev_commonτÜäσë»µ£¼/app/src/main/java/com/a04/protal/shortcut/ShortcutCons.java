package com.a04.protal.shortcut;



public class ShortcutCons {
    public static final String SHORTCUT="shortcut";

    public static final String SHORTCUT_AGQJ = "ShortcutAGQJ";
    public static final String SHORTCUT_AGIN = "ShortcutAGIN";
    public static final String SHORTCUT_WITHDRAW = "ShortcutWithdraw";
    public static final String SHORTCUT_DEPOSIT = "ShortcutDeposit";
}