package com.a04.protal.records.model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;

public class RecordsModel implements Serializable {


    /**
     * data : [{"accountNo":"5*************74","amount":50002,"bankAccountType":"借记卡","bankCode":"CITIC","bankName":"中信银行","catalog":"0","createDate":"2020-12-14 10:33:31","currency":"CNY","deleteFlag":true,"flag":2,"flagDesc":"批准","itemIcon":"/cdn/A04FM/externals/img/_wms/bankcards/ca0abbd5072cf6b116fbfd50583965b5.png","loginName":"mfinn505","processedDate":"2020-12-14 10:37:46","rate":1,"requestId":"A04022012141040AA01","targetCurrency":"CNY","title":"银行卡","transAmount":50002,"updateDate":"2020-12-14 11:50:25"},{"accountNo":"5*************74","amount":5000,"bankAccountType":"借记卡","bankCode":"CITIC","bankName":"中信银行","catalog":"0","createDate":"2020-12-11 12:42:12","currency":"CNY","deleteFlag":true,"flag":-2,"flagDesc":"后台取消","itemIcon":"/cdn/A04FM/externals/img/_wms/bankcards/ca0abbd5072cf6b116fbfd50583965b5.png","loginName":"mfinn505","rate":1,"requestId":"A04022012111248AA01","targetCurrency":"CNY","title":"银行卡","transAmount":5000,"updateDate":"2020-12-14 10:31:04"},{"accountNo":"5*************74","amount":20008,"bankAccountType":"借记卡","bankCode":"CITIC","bankName":"中信银行","catalog":"0","createDate":"2020-12-11 10:18:29","currency":"CNY","deleteFlag":true,"flag":-2,"flagDesc":"后台取消","itemIcon":"/cdn/A04FM/externals/img/_wms/bankcards/ca0abbd5072cf6b116fbfd50583965b5.png","loginName":"mfinn505","rate":1,"requestId":"A04022012111024AA01","targetCurrency":"CNY","title":"银行卡","transAmount":20008,"updateDate":"2020-12-11 12:10:16"},{"accountNo":"5*************74","amount":5000,"bankAccountType":"借记卡","bankCode":"CITIC","bankName":"中信银行","catalog":"0","createDate":"2020-12-07 10:47:32","currency":"CNY","deleteFlag":true,"flag":-2,"flagDesc":"后台取消","itemIcon":"/cdn/A04FM/externals/img/_wms/bankcards/ca0abbd5072cf6b116fbfd50583965b5.png","loginName":"mfinn505","rate":1,"requestId":"A04022012071050AA01","targetCurrency":"CNY","title":"银行卡","transAmount":5000,"updateDate":"2020-12-11 10:17:56"}]
     * extra : {"sumAmount":50002}
     * pageNo : 1
     * pageSize : 500
     * totalPage : 1
     * totalRow : 4
     */

    @SerializedName("pageNo")
    private int pageNo;
    @SerializedName("pageSize")
    private int pageSize;
    @SerializedName("totalPage")
    private int totalPage;
    @SerializedName("totalRow")
    private int totalRow;
    @SerializedName("extra")
    private ExtraModel extraModel;
    @SerializedName("data")
    private List<GeneralRecordModel> recordsData;

    public int getPageNo() {
        return pageNo;
    }

    public void setPageNo(int pageNo) {
        this.pageNo = pageNo;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public int getTotalRow() {
        return totalRow;
    }

    public void setTotalRow(int totalRow) {
        this.totalRow = totalRow;
    }

    public ExtraModel getExtraModel() {
        return extraModel;
    }

    public void setExtraModel(ExtraModel extraModel) {
        this.extraModel = extraModel;
    }

    public List<GeneralRecordModel> getRecordsData() {
        return recordsData;
    }

    public void setRecordsData(List<GeneralRecordModel> data) {
        this.recordsData = data;
    }

    public static class ExtraModel implements Serializable{
        /**
         * sumAmount : 50002
         */

        @SerializedName("sumAmount")
        private double sumAmount;

        public double getSumAmount() {
            return sumAmount;
        }

        public void setSumAmount(double sumAmount) {
            this.sumAmount = sumAmount;
        }
    }

    public static class GeneralRecordModel implements Serializable {
        /**
         * accountNo : 5*************74
         * amount : 50002
         * bankAccountType : 借记卡
         * bankCode : CITIC
         * bankName : 中信银行
         * catalog : 0
         * createDate : 2020-12-14 10:33:31
         * currency : CNY
         * deleteFlag : true
         * flag : 2
         * flagDesc : 批准
         * itemIcon : /cdn/A04FM/externals/img/_wms/bankcards/ca0abbd5072cf6b116fbfd50583965b5.png
         * loginName : mfinn505
         * processedDate : 2020-12-14 10:37:46
         * rate : 1
         * requestId : A04022012141040AA01
         * targetCurrency : CNY
         * title : 银行卡
         * transAmount : 50002
         * updateDate : 2020-12-14 11:50:25
         *
         *
         */

        @SerializedName("accountNo")
        private String accountNo;
        @SerializedName("amount")
        private double amount;
        @SerializedName("bankAccountType")
        private String bankAccountType;
        @SerializedName("bankCode")
        private String bankCode;
        @SerializedName("bankName")
        private String bankName;
        @SerializedName("catalog")
        private String catalog;
        @SerializedName("createDate")
        private String createDate;
        @SerializedName("currency")
        private String currency;
        @SerializedName("deleteFlag")
        private boolean deleteFlag;
        @SerializedName("flag")
        private int flag;
        @SerializedName("flagDesc")
        private String flagDesc;
        @SerializedName("itemIcon")
        private String itemIcon;
        @SerializedName("loginName")
        private String loginName;
        @SerializedName("processedDate")
        private String processedDate;
        @SerializedName("rate")
        private float rate;
        @SerializedName("requestId")
        private String requestId;
        @SerializedName("targetCurrency")
        private String targetCurrency;
        @SerializedName("title")
        private String title;
        @SerializedName("transAmount")
        private double transAmount;
        @SerializedName("updateDate")
        private String updateDate;

        //存款

        @SerializedName("appealFlag")
        private int appealFlag;
        @SerializedName("transCode")
        private int transCode;
        @SerializedName("fee")
        private String fee;
        @SerializedName("sourceCurrency")
        private String sourceCurrency;
        @SerializedName("lastUpdate")
        private String lastUpdate;

        //洗碼
        @SerializedName("gameKind")
        private String gameKind;

        //轉換
        @SerializedName("sourceCredit")
        private String sourceCredit;
        @SerializedName("srcCurrency")
        private String srcCurrency;
        @SerializedName("targetCredit")
        private String targetCredit;
        @SerializedName("tgtCurrency")
        private String tgtCurrency;
        @SerializedName("createdDate")
        private String createdDate;



        public String getAccountNo() {
            return accountNo;
        }

        public void setAccountNo(String accountNo) {
            this.accountNo = accountNo;
        }

        public double getAmount() {
            return amount;
        }

        public void setAmount(double amount) {
            this.amount = amount;
        }

        public String getBankAccountType() {
            return bankAccountType;
        }

        public void setBankAccountType(String bankAccountType) {
            this.bankAccountType = bankAccountType;
        }

        public String getBankCode() {
            return bankCode;
        }

        public void setBankCode(String bankCode) {
            this.bankCode = bankCode;
        }

        public String getBankName() {
            return bankName;
        }

        public void setBankName(String bankName) {
            this.bankName = bankName;
        }

        public String getCatalog() {
            return catalog;
        }

        public void setCatalog(String catalog) {
            this.catalog = catalog;
        }

        public String getCreateDate() {
            return createDate;
        }

        public void setCreateDate(String createDate) {
            this.createDate = createDate;
        }

        public String getCurrency() {
            return currency;
        }

        public void setCurrency(String currency) {
            this.currency = currency;
        }

        public boolean isDeleteFlag() {
            return deleteFlag;
        }

        public void setDeleteFlag(boolean deleteFlag) {
            this.deleteFlag = deleteFlag;
        }

        public int getFlag() {
            return flag;
        }

        public void setFlag(int flag) {
            this.flag = flag;
        }

        public String getFlagDesc() {
            return flagDesc;
        }

        public void setFlagDesc(String flagDesc) {
            this.flagDesc = flagDesc;
        }

        public String getItemIcon() {
            return itemIcon;
        }

        public void setItemIcon(String itemIcon) {
            this.itemIcon = itemIcon;
        }

        public String getLoginName() {
            return loginName;
        }

        public void setLoginName(String loginName) {
            this.loginName = loginName;
        }

        public String getProcessedDate() {
            return processedDate;
        }

        public void setProcessedDate(String processedDate) {
            this.processedDate = processedDate;
        }

        public float getRate() {
            return rate;
        }

        public void setRate(float rate) {
            this.rate = rate;
        }

        public String getRequestId() {
            return requestId;
        }

        public void setRequestId(String requestId) {
            this.requestId = requestId;
        }

        public String getTargetCurrency() {
            return targetCurrency;
        }

        public void setTargetCurrency(String targetCurrency) {
            this.targetCurrency = targetCurrency;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public double getTransAmount() {
            return transAmount;
        }

        public void setTransAmount(double transAmount) {
            this.transAmount = transAmount;
        }

        public String getUpdateDate() {
            return updateDate;
        }

        public void setUpdateDate(String updateDate) {
            this.updateDate = updateDate;
        }

        public int getAppealFlag() {
            return appealFlag;
        }

        public void setAppealFlag(int appealFlag) {
            this.appealFlag = appealFlag;
        }

        public int getTransCode() {
            return transCode;
        }

        public void setTransCode(int transCode) {
            this.transCode = transCode;
        }

        public String getFee() {
            return fee;
        }

        public void setFee(String fee) {
            this.fee = fee;
        }

        public String getSourceCurrency() {
            return sourceCurrency;
        }

        public void setSourceCurrency(String sourceCurrency) {
            this.sourceCurrency = sourceCurrency;
        }

        public String getLastUpdate() {
            return lastUpdate;
        }

        public void setLastUpdate(String lastUpdate) {
            this.lastUpdate = lastUpdate;
        }

        public String getGameKind() {
            return gameKind;
        }

        public void setGameKind(String gameKind) {
            this.gameKind = gameKind;
        }

        public String getSourceCredit() {
            return sourceCredit;
        }

        public void setSourceCredit(String sourceCredit) {
            this.sourceCredit = sourceCredit;
        }

        public String getSrcCurrency() {
            return srcCurrency;
        }

        public void setSrcCurrency(String srcCurrency) {
            this.srcCurrency = srcCurrency;
        }

        public String getTargetCredit() {
            return targetCredit;
        }

        public void setTargetCredit(String targetCredit) {
            this.targetCredit = targetCredit;
        }

        public String getTgtCurrency() {
            return tgtCurrency;
        }

        public void setTgtCurrency(String tgtCurrency) {
            this.tgtCurrency = tgtCurrency;
        }

        public String getCreatedDate() {
            return createdDate;
        }

        public void setCreatedDate(String createdDate) {
            this.createdDate = createdDate;
        }
    }
}
