package com.a04.protal.records.model.adapter;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.a04.protal.R;
import com.a04.protal.http.HttpApi;
import com.a04.protal.http.HttpCallBack;
import com.a04.protal.records.model.PromotionRecordModel;
import com.a04.protal.records.model.RecordsModel;
import com.a04.protal.utils.EventHelper;
import com.a04.protal.utils.UserHelper;
import com.a04.protal.utils.Util;
import com.a04.protal.records.RecordsActivity.RecordType;
import com.in.hybrid.utils.ScreenUtil;
import com.in.toast.ToastUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import in.net.base.netlibrary.model.ResponseModel;
import in.net.base.netlibrary.request.Request;

public class RecordsItemAdapter extends RecyclerView.Adapter<RecordsItemAdapter.Holder> {

    private static final int TYPE_HEADER = 0;
    private static final int TYPE_ITEM = 1;
    private static final int TYPE_FOOTER = 2;

    private List<RecordsModel.GeneralRecordModel> mRecordsDataList;  //优惠分页以外的分页用
    private Context mContext;
    private boolean isUsdt = UserHelper.INSTANT.isUsdtMode();
    private double mTotalTxnAmount = 0;
    private RecordType mRecordType = RecordType.WITHDRAW;
    private ArrayList<Integer> withFeeList = new ArrayList<Integer>() {{  // 有开放显示手续费的 存款方式
        add(4);
        add(5);
        add(8);
        add(9);
    }};

    public RecordsItemAdapter(Context context) {
        this.mContext = context;
    }

    @Override
    @NonNull
    public Holder onCreateViewHolder (@NonNull ViewGroup parent, int viewType) {
        if(viewType == TYPE_HEADER) {
            View v = LayoutInflater.from (mContext).inflate (R.layout.item_records_header, parent, false);
            return new RecordHeaderViewHolder(v);
        } else if(viewType == TYPE_FOOTER) {
            View v = LayoutInflater.from (mContext).inflate (R.layout.item_records_footer, parent, false);
            return new RecordFooterViewHolder(v);
        } else {
            View v = LayoutInflater.from (mContext).inflate (R.layout.item_records, parent, false);
            return new RecordItemViewHolder(v);
        }
    }

    @Override
    public void onBindViewHolder (@NonNull Holder holder, int position) {

        if(holder instanceof RecordHeaderViewHolder) {
            RecordHeaderViewHolder headerHolder = (RecordHeaderViewHolder) holder;
            if(mRecordType == RecordType.WITHDRAW) {
                headerHolder.tvTotalTxnAmount.setVisibility(View.VISIBLE);
                headerHolder.tvTotalTxnAmount.setText(Util.formatDecimalPoint2(mTotalTxnAmount) +
                        "\n共取款(" + (isUsdt ? "USDT" : "元") + ")");
            } else {
                headerHolder.tvTotalTxnAmount.setVisibility(View.GONE);
            }
        } else if(holder instanceof RecordItemViewHolder) {
            if(null == mRecordType || Util.isListEmpty(mRecordsDataList)) return;
            RecordItemViewHolder itemHolder = (RecordItemViewHolder) holder;
            PromotionRecordModel promoData = null;
            RecordsModel.GeneralRecordModel recordData = null;
            recordData = mRecordsDataList.get(position - 1);

            switch (mRecordType) {
                case WITHDRAW:
                    setWithdrawItem(itemHolder, recordData);
                    break;
                case DEPOSIT:
                    setDepositItem(itemHolder, recordData);
                    break;
                case EXCHANGE:
                    setExchangeItem(itemHolder, recordData);
                    break;
                case XM:
                    setXmItem(itemHolder, recordData);
                    break;
            }
        }
    }

    @Override
    public int getItemViewType (int position) {
        if(position == 0) {
            return TYPE_HEADER;
        } else if(isPositionFooter (position)) {
            return TYPE_FOOTER;
        }
        return TYPE_ITEM;
    }

    @Override
    public int getItemCount () {
        return getListSize() + 2;
    }

    private boolean isPositionFooter (int position) {
        return position == getListSize() + 1;
    }

    private int getListSize() {
        return Util.isListEmpty(mRecordsDataList)? 0 : mRecordsDataList.size();
    }

    private void setWithdrawItem(RecordItemViewHolder itemHolder, RecordsModel.GeneralRecordModel recordData) {
        EventHelper.setVisibility(View.VISIBLE, itemHolder.tvAmount, itemHolder.tvAccountInfo);
        EventHelper.setVisibility(View.GONE,  itemHolder.layoutTxn, itemHolder.layoutExchangeTop, itemHolder.layoutExchangeBottom);

        setTxnHurryUI(itemHolder, recordData);

        itemHolder.tvAmount.setText(Util.formatDecimalPoint2(recordData.getAmount()) + (isUsdt? "USDT" : "元") );
        itemHolder.tvUpdateTime.setText(null == recordData.getUpdateDate()? recordData.getCreateDate() : recordData.getUpdateDate());

        StringBuilder sb1 = new StringBuilder();
        sb1.append(recordData.getBankName() + "(" + recordData.getAccountNo().substring(recordData.getAccountNo().length() - 4) + ")");
        if(recordData.getTargetCurrency().equalsIgnoreCase("USDT") && !isUsdt) {
            sb1.append("\n" + Util.formatDecimalPoint2(recordData.getTransAmount()) + " USDT");
        }
        if(recordData.getBankName().equalsIgnoreCase("USDT") && recordData.getRate() > 0 && !isUsdt) {
            sb1.append("\n" + "汇率1USDT≈" + recordData.getRate() + "RMB");
        }
        itemHolder.tvAccountInfo.setText(sb1.toString());
        setCommonTxnStatus(itemHolder, recordData.getFlag());
    }

    private void setDepositItem(RecordItemViewHolder itemHolder, RecordsModel.GeneralRecordModel recordData) {
        EventHelper.setVisibility(View.VISIBLE, itemHolder.tvAmount, itemHolder.layoutTxn, itemHolder.tvAccountInfo);
        EventHelper.setVisibility(View.GONE, itemHolder.layoutExchangeTop, itemHolder.layoutExchangeBottom);

        setTxnHurryUI(itemHolder, recordData);

        StringBuilder sb2 = new StringBuilder();
        if(recordData.getSourceCurrency().equalsIgnoreCase("USDT")) {
            sb2.append("USDT支付-" + recordData.getBankName() + "钱包");
        }else {
            sb2.append(recordData.getTitle());
        }
        if(recordData.getSourceCurrency().equalsIgnoreCase("USDT") && !isUsdt) {
            sb2.append("\n" + Util.formatDecimalPoint2(recordData.getTransAmount()) + " USDT");
        }
        if(withFeeList.indexOf(recordData.getTransCode()) > -1 && !isUsdt && !TextUtils.isEmpty(recordData.getFee())) {
            sb2.append("\n" + "手续费" + recordData.getFee() + "元");
        }
        if(recordData.getSourceCurrency().equalsIgnoreCase("USDT") && !isUsdt && recordData.getRate() > 0) {
            sb2.append("\n" + "汇率1USDT≈" + recordData.getRate() + "RMB");
        }
        if(recordData.getSourceCurrency().equalsIgnoreCase("BTC") && !isUsdt && recordData.getRate() > 0) {
            sb2.append("\n" + "汇率1BTC≈" + recordData.getRate() + "RMB");
        }
        itemHolder.tvAmount.setText(Util.formatDecimalPoint2(recordData.getAmount()) + (isUsdt? "USDT" : "元") );
        itemHolder.tvAccountInfo.setText(sb2.toString());
        itemHolder.tvUpdateTime.setText(null == recordData.getLastUpdate()? recordData.getCreateDate() : recordData.getLastUpdate());
        itemHolder.tvTxnInfo.setText("订单号 " + recordData.getRequestId());
        if(recordData.getFlag() == 0) {
            itemHolder.tvCopyTxnNo.setVisibility(View.VISIBLE);
            itemHolder.tvCopyTxnNo.setPaintFlags(itemHolder.tvCopyTxnNo.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
            itemHolder.tvCopyTxnNo.setText("复制订单");
            itemHolder.tvCopyTxnNo.setOnClickListener(view -> {
                copyTxnNo(recordData.getRequestId());
            });
        }else {
            itemHolder.tvCopyTxnNo.setVisibility(View.GONE);
            itemHolder.tvCopyTxnNo.setOnClickListener(null);
        }
        setCommonTxnStatus(itemHolder, recordData.getFlag());
    }

    private void setExchangeItem(RecordItemViewHolder itemHolder, RecordsModel.GeneralRecordModel recordData) {
        EventHelper.setVisibility(View.VISIBLE, itemHolder.layoutExchangeTop, itemHolder.layoutExchangeBottom);
        EventHelper.setVisibility(View.GONE, itemHolder.tvAmount, itemHolder.tvTxnHurry, itemHolder.layoutTxn, itemHolder.tvAccountInfo);

        boolean isSourceUsdt = recordData.getSrcCurrency().equalsIgnoreCase("USDT");
        boolean isTargetUsdt = recordData.getTgtCurrency().equalsIgnoreCase("USDT");
        itemHolder.ivSrcCurrency.setImageResource(isSourceUsdt? R.drawable.ic_usdt_circle : R.drawable.ic_cny_circle);
        itemHolder.ivTrgtCurrency.setImageResource(isTargetUsdt? R.drawable.ic_usdt_circle : R.drawable.ic_cny_circle);
        itemHolder.tvExchangeSource.setText(Util.formatDecimalPoint2(recordData.getSourceCredit()) + (isSourceUsdt? " USDT" : " 元"));
        itemHolder.tvExchangeTarget.setText(Util.formatDecimalPoint2(recordData.getTargetCredit()) + (isTargetUsdt? " USDT" : " 元"));
        setCommonTxnStatus(itemHolder, recordData.getFlag());
    }

    private void setXmItem(RecordItemViewHolder itemHolder, RecordsModel.GeneralRecordModel recordData) {
        EventHelper.setVisibility(View.VISIBLE, itemHolder.tvAmount, itemHolder.tvAccountInfo);
        EventHelper.setVisibility(View.GONE, itemHolder.tvTxnHurry, itemHolder.layoutTxn, itemHolder.layoutExchangeTop, itemHolder.layoutExchangeBottom);

        itemHolder.tvAmount.setText(Util.formatDecimalPoint2(recordData.getAmount()) + (isUsdt? "USDT" : "元") );
        itemHolder.tvUpdateTime.setText(null == recordData.getUpdateDate()? recordData.getCreateDate() : recordData.getUpdateDate());
        setXmGameKindString(itemHolder, recordData.getGameKind());
        setCommonTxnStatus(itemHolder, recordData.getFlag());
    }

    private void setCommonTxnStatus(RecordItemViewHolder viewHolder, int flag) {
        switch (flag) {
            case 0:
                viewHolder.tvTxnStatus.setText("待审核");
                viewHolder.tvTxnStatus.setTextColor(Color.parseColor("#e7b145"));
                break;
            case 1:
                viewHolder.tvTxnStatus.setText(mRecordType == RecordType.EXCHANGE? "处理中" : "正在处理");
                viewHolder.tvTxnStatus.setTextColor(Color.parseColor("#e7b145"));
                break;
            case 2:
                if(mRecordType == RecordType.XM)
                    viewHolder.tvTxnStatus.setText("审核通过");
                else if(mRecordType == RecordType.EXCHANGE)
                    viewHolder.tvTxnStatus.setText("已通过");
                else
                    viewHolder.tvTxnStatus.setText("已完成");
                viewHolder.tvTxnStatus.setTextColor(Color.parseColor("#6dd400"));
                break;
            case 9:
                viewHolder.tvTxnStatus.setText("审核中");
                viewHolder.tvTxnStatus.setTextColor(Color.parseColor("#e7b145"));
                break;
            case 97:
                viewHolder.tvTxnStatus.setText("等待付款");
                viewHolder.tvTxnStatus.setTextColor(Color.parseColor("#e7b145"));
                break;
            case 99:
                viewHolder.tvTxnStatus.setText("已超时");
                viewHolder.tvTxnStatus.setTextColor(Color.parseColor("#ff3636"));
                break;
            case -1:
            case 98:
                viewHolder.tvTxnStatus.setText("已取消");
                viewHolder.tvTxnStatus.setTextColor(Color.parseColor("#ff3636"));
                break;
            case -2:
                viewHolder.tvTxnStatus.setText("系统取消");
                viewHolder.tvTxnStatus.setTextColor(Color.parseColor("#ff3636"));
                break;
            case -3:
                viewHolder.tvTxnStatus.setText(mRecordType == RecordType.XM? "审核拒绝" : "已拒绝");
                viewHolder.tvTxnStatus.setTextColor(Color.parseColor("#ff3636"));
                break;
        }

    }

    private void setXmGameKindString(RecordItemViewHolder viewHolder, String gameKind) {
        String gameKindStr = "";
        switch (gameKind) {
            case "1":
                gameKindStr = "体育厅";
                break;
            case "2":
                gameKindStr = "电投厅";
                break;
            case "3":
                gameKindStr = "真人厅";
                break;
            case "5":
                gameKindStr = "电游厅";
                break;
            case "6":
                gameKindStr = "麻将厅";
                break;
            case "7":
                gameKindStr = "对战/德州扑克厅";
                break;
            case "8":
                gameKindStr = "捕鱼厅";
                break;
            case "12":
                gameKindStr = "彩票厅";
                break;
            case "15":
                gameKindStr = "3D厅";
                break;
            case "20":
                gameKindStr = "牛牛厅";
                break;
        }
        viewHolder.tvAccountInfo.setText(gameKindStr);
    }

    private void setTxnHurryUI(RecordItemViewHolder holder, RecordsModel.GeneralRecordModel recordModel) {
        if(null == holder || null == holder.tvTxnHurry) return;
        boolean haveHurried = false;   //判断显示催单或已催单

        switch (mRecordType) {
            case WITHDRAW:
                if(recordModel.getAppealFlag() == 1) {
                    haveHurried = true;
                }else if(recordModel.getFlag() == 0 || recordModel.getFlag() == 1 || recordModel.getFlag() == 9) {
                    haveHurried = false;
                }else {
                    holder.tvTxnHurry.setVisibility(View.GONE);
                }
                break;
            case DEPOSIT:
                if(recordModel.getFlag() == 0) {
                    holder.tvTxnHurry.setVisibility(View.VISIBLE);
                    if(recordModel.getAppealFlag() == 1) {
                        haveHurried = true;
                    }else {
                        haveHurried = false;
                    }
                }else {
                    holder.tvTxnHurry.setVisibility(View.GONE);
                }
                break;
            default:
                holder.tvTxnHurry.setVisibility(View.GONE);
                return;
        }

        if(holder.tvTxnHurry.getVisibility() == View.GONE) return;

        if(haveHurried) {
            holder.tvTxnHurry.setText("已催单");
            holder.tvTxnHurry.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
            holder.tvTxnHurry.setOnClickListener(null);
        } else {
            holder.tvTxnHurry.setText("催单");
            holder.tvTxnHurry.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_txn_hurry, 0, 0, 0);
            holder.tvTxnHurry.setCompoundDrawablePadding(ScreenUtil.dp2px(mContext, 10));
            switch(mRecordType) {
                case WITHDRAW:
                    holder.tvTxnHurry.setOnClickListener(view -> {
                        copyTxnNo(recordModel.getRequestId());
                    });
                    break;
                case DEPOSIT:
                    holder.tvTxnHurry.setOnClickListener(view -> {
                        requestTxnHurry(recordModel.getRequestId(), new HttpCallBack<Object>(false, true) {
                            @Override
                            public void onCallBackSuccess(Object o, ResponseModel.Head head) {
                                holder.tvTxnHurry.setText("已催单");
                                holder.tvTxnHurry.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
                                holder.tvTxnHurry.setOnClickListener(null);
                            }
                        });
                    });
                    break;
            }

        }
    }

    private void requestTxnHurry(String txnNo, HttpCallBack<Object> httpCallBack) {
        Map<String, Object> params = new HashMap<>();
        params.put("referenceId", txnNo);
        params.put("type", 1);
        Request.with(mContext).loading().post(HttpApi.TXN_HURRY, params, httpCallBack);
    }

    private void copyTxnNo(String txnNo) {
        Util.copyText("txnNo", txnNo, false);
        ToastUtils.toastSuccess("该订单信息已复制，请粘贴咨询客服！");
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Util.goLive800Deposit();
            }
        }, 1000);
    }

    public void setTotalWithdrawAmount(double totalTxnAmount) {
        mTotalTxnAmount = totalTxnAmount;
    }

    public void setList(List<RecordsModel.GeneralRecordModel> recordModels) {
        if (mRecordsDataList == null) {
            mRecordsDataList = new ArrayList<>();
        }else {
            mRecordsDataList.clear();
        }
        if (mRecordsDataList != null) {
            mRecordsDataList.addAll(recordModels);
        }
    }

    public void setRecordType(RecordType recordType) {
        this.mRecordType = recordType;
    }

    class Holder extends RecyclerView.ViewHolder {

        private Holder(View itemView) {
            super(itemView);
        }
    }

    class RecordFooterViewHolder extends Holder {

        public RecordFooterViewHolder(View itemView) {
            super (itemView);
        }
    }

    class RecordHeaderViewHolder extends Holder {
        TextView tvTotalTxnAmount;

        public RecordHeaderViewHolder(View itemView) {
            super (itemView);
            this.tvTotalTxnAmount = (TextView) itemView.findViewById (R.id.tv_total_txn_amount);
        }
    }

    class RecordItemViewHolder extends Holder {

        TextView tvAmount;
        TextView tvTxnHurry;
        TextView tvUpdateTime;
        TextView tvAccountInfo;
        TextView tvTxnStatus;
        ConstraintLayout layoutTxn;
        TextView tvTxnInfo;
        TextView tvCopyTxnNo;

        LinearLayout layoutExchangeTop;
        LinearLayout layoutExchangeBottom;
        ImageView ivSrcCurrency;
        ImageView ivTrgtCurrency;
        TextView tvExchangeSource;
        TextView tvExchangeTarget;


        public RecordItemViewHolder(View itemView) {
            super (itemView);
            tvAmount = (TextView) itemView.findViewById(R.id.tv_amount);
            tvTxnHurry = (TextView) itemView.findViewById(R.id.tv_txn_hurry);
            tvUpdateTime = (TextView) itemView.findViewById(R.id.tv_update_time);
            tvAccountInfo = (TextView) itemView.findViewById(R.id.tv_account_info);
            tvTxnStatus = (TextView) itemView.findViewById(R.id.tv_txn_status);

            layoutTxn = (ConstraintLayout) itemView.findViewById(R.id.layout_txn);
            tvTxnInfo = (TextView) itemView.findViewById(R.id.tv_txn_info);
            tvCopyTxnNo = (TextView) itemView.findViewById(R.id.tv_copy_txn_no);

            layoutExchangeTop = (LinearLayout) itemView.findViewById(R.id.layout_exchangeTop);
            layoutExchangeBottom = (LinearLayout) itemView.findViewById(R.id.layout_exchange_bottom);
            ivSrcCurrency = (ImageView) itemView.findViewById(R.id.iv_src_currency);
            ivTrgtCurrency = (ImageView) itemView.findViewById(R.id.iv_trgt_currency);
            tvExchangeSource = (TextView) itemView.findViewById(R.id.tv_exchange_source);
            tvExchangeTarget = (TextView) itemView.findViewById(R.id.tv_exchange_target);


        }
    }

}
