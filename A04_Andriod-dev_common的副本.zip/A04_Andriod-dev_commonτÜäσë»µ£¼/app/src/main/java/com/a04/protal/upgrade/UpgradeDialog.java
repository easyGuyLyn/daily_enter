package com.a04.protal.upgrade;

import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import com.a04.protal.R;
import com.a04.protal.utils.HomeDialogHelper;
import com.a04.protal.utils.Util;
import com.in.autoupdate.AbstractUpdateDialog;
import com.in.hybrid.utils.ScreenUtil;

/**
 * Author:Javan.W
 * Time:2018/12/13
 * Description:This is UpgradeDialog
 */
public class UpgradeDialog extends AbstractUpdateDialog implements View.OnClickListener {
    private View mRootView;
    private View mUpdateLayout;
    private View mProgressView;
    private TextView mProgressText;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        setStyle(DialogFragment.STYLE_NORMAL, android.R.style.Theme_Holo_Light_NoActionBar_Fullscreen);
    }

    @Override
    public void onStart() {
        super.onStart();
        getDialog().setCanceledOnTouchOutside(false);

        Window win = getDialog().getWindow();
        win.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        getActivity().getWindowManager().getDefaultDisplay().getMetrics(new DisplayMetrics());
        WindowManager.LayoutParams params = win.getAttributes();
        params.width = ScreenUtil.getScreenWidth(getActivity());
        params.height = ScreenUtil.getScreenHeight(getContext());
        win.setAttributes(params);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        mRootView = inflater.inflate(R.layout.dialog_upgrade, null);
        mUpdateLayout = mRootView.findViewById(R.id.rl_update_content);
        mProgressView = mRootView.findViewById(R.id.rl_update_progress);
        mProgressText = mRootView.findViewById(R.id.tv_progress);

        TextView tvCancel = mRootView.findViewById(R.id.tv_cancel);
        TextView twUpdateMsg = mRootView.findViewById(R.id.tv_update_msg);
        mUpdateLayout.setVisibility(View.VISIBLE);
        mProgressView.setVisibility(View.GONE);
        if (mAutoUpdateModel != null && mAutoUpdateModel.getFlag() == 2) {
            tvCancel.setVisibility(View.GONE);
            getDialog().setCancelable(false);
        } else {
            tvCancel.setVisibility(View.VISIBLE);
            getDialog().setCancelable(true);
        }
        if (mAutoUpdateModel.getUpgradeDesc() != null && !Util.isListEmpty(mAutoUpdateModel.getUpgradeDesc().getNotes())) {
            String updateDesc = "";
            for (int i = 0; i < mAutoUpdateModel.getUpgradeDesc().getNotes().size(); i++) {
                if (i != mAutoUpdateModel.getUpgradeDesc().getNotes().size() - 1) {
                    updateDesc = updateDesc + mAutoUpdateModel.getUpgradeDesc().getNotes().get(i) + "\n";
                } else {
                    updateDesc = updateDesc + mAutoUpdateModel.getUpgradeDesc().getNotes().get(i);
                }
            }
            twUpdateMsg.setText(updateDesc);
        }
        tvCancel.setOnClickListener(this);
        mRootView.findViewById(R.id.tv_update).setOnClickListener(this);

        return mRootView;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tv_cancel:
                dismissAllowingStateLoss();
                break;
            case R.id.tv_update:
                mUpdateLayout.setVisibility(View.GONE);
                mProgressView.setVisibility(View.VISIBLE);
                mProgressText.setText("正在更新版本　0%...");
                startDownload();
                break;
        }
    }

    @Override
    public void onDownloadProgress(long currentSize, long totalSize, float progress, long networkSpeed) {
        int pro = (int) (progress * 100);
        mProgressText.setText("正在更新版本　" + pro + "%...");
    }

    @Override
    public void onDismiss(DialogInterface dialog) {
        super.onDismiss(dialog);
        HomeDialogHelper.getInstance().setUpdateShowing(false);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        try {
            cancelDownload();
        }catch (Exception e) {
            e.printStackTrace();
        }
    }
}
