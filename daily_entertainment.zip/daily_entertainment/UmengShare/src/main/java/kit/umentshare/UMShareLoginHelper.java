package kit.umentshare;

import android.content.Context;

import com.umeng.socialize.BuildConfig;
import com.umeng.socialize.Config;
import com.umeng.socialize.PlatformConfig;
import com.umeng.socialize.UMShareAPI;
import com.umeng.socialize.UMShareConfig;
import com.umeng.socialize.utils.Log;

/**
 * Created by lfp on 2017/6/1.
 */

public class UMShareLoginHelper {

    public static final String weiXinId = "wx5b31120f68514b23";
    public static final String weiXinSecrest = "ea824a3677f7d52abf72b091b6df025c";

    public static final String qqId = "101882960";
    public static final String qqSecrest = "deee75a1a0e3af520cc25b3701a7bd7b";


    public static final void init(Context c) {


        PlatformConfig.setWeixin(weiXinId, weiXinSecrest);
        PlatformConfig.setQQZone(qqId, qqSecrest);
        UMShareAPI.get(c);
        com.umeng.socialize.Config.isUmengSina = true;
        Config.isJumptoAppStore = true; //对应平台没有安装的时候跳转转到应用商店下载

        if (BuildConfig.DEBUG) {
            //开启debug模式，方便定位错误，具体错误检查方式可以查看http://dev.umeng.com/social/android/quick-integration的报错必看，正式发布，请关闭该模式
            Config.DEBUG = true;
            Log.LOG = true;
        }

        //分享编辑页面
//        注意此接口只有在新浪精简版、豆瓣和人人分享时生效，微信、QQ的分享编辑页为原生SDK提供，无法去除
        UMShareConfig config = new UMShareConfig();
        config.isOpenShareEditActivity(true);
        config.isNeedAuthOnGetUserInfo(true);
        UMShareAPI.get(c).setShareConfig(config);

    }

}
