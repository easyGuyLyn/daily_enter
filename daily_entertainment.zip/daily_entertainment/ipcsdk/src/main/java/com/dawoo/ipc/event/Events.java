package com.dawoo.ipc.event;

/**
 * archar  天纵神武
 **/
public class Events {
    public static final String PING = "ping";
    public static final String EVENT_REFRSH_API = "EVENT_REFRSH_API";
    public static final String SERVER_DIE = "server_die";
}
