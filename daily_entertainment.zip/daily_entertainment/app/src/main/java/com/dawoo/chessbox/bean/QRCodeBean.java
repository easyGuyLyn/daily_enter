package com.dawoo.chessbox.bean;

public class QRCodeBean {

    public String qrCodeUrl;
}
