package com.dawoo.chessbox.net.rx;

public interface SubscriberOnNextListener<T> {
    void onNext(T t);
}
