package com.dawoo.chessbox.bean;

import java.io.Serializable;

/**
 * archar  天纵神武
 **/
public class UpdateBean implements Serializable {

    private int VersionNo;
    private String AppName;
    private boolean IsMandatory;
    private String UpgradeMsg;

    private String DownLoadUrl;

    public int getVersionNo() {
        return VersionNo;
    }

    public void setVersionNo(int versionNo) {
        VersionNo = versionNo;
    }

    public String getAppName() {
        return AppName;
    }

    public void setAppName(String appName) {
        AppName = appName;
    }

    public boolean isMandatory() {
        return IsMandatory;
    }

    public void setMandatory(boolean mandatory) {
        IsMandatory = mandatory;
    }

    public String getUpgradeMsg() {
        return UpgradeMsg;
    }

    public void setUpgradeMsg(String upgradeMsg) {
        UpgradeMsg = upgradeMsg;
    }

    public String getDownLoadUrl() {
        return DownLoadUrl;
    }

    public void setDownLoadUrl(String downLoadUrl) {
        DownLoadUrl = downLoadUrl;
    }
}
