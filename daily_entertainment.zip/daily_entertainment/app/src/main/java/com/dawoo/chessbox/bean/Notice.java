package com.dawoo.chessbox.bean;

import java.util.List;

/**
 * 公告
 * Created by benson on 17-12-29.
 */

public class Notice {

    public static class AnnouncementBean {

        private String NoticeId;
        private String Title;

        public String getId() {
            return NoticeId;
        }

        public void setId(String id) {
            this.NoticeId = id;
        }

        public String getTitle() {
            return Title;
        }

        public void setTitle(String title) {
            this.Title = title;
        }

    }
}
