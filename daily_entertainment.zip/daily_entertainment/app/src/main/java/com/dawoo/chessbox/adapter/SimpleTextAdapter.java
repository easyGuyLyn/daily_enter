package com.dawoo.chessbox.adapter;


import android.content.Context;
import android.text.TextUtils;
import android.widget.TextView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.dawoo.chessbox.R;
import com.dawoo.chessbox.bean.FavourableCenterBean;
import com.dawoo.chessbox.bean.ttc.user.rep.CurrentCardRepBean;

public class SimpleTextAdapter extends BaseQuickAdapter {

    private Context context;

    public SimpleTextAdapter(Context context, int layoutResId) {
        super(layoutResId);
        this.context = context;
    }

    @Override
    protected void convert(BaseViewHolder helper, Object item) {
        CurrentCardRepBean favourableBean = (CurrentCardRepBean) item;

        helper.setText(R.id.item_text, favourableBean.getBankName() + ": " + favourableBean.getBankCardNumber());

    }

}
