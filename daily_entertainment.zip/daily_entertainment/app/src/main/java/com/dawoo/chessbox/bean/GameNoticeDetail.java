package com.dawoo.chessbox.bean;

/**
 * Created by benson on 18-1-15.
 */

public class GameNoticeDetail {
}
