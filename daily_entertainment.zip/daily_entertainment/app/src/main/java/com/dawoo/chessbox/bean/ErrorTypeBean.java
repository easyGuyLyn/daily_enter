package com.dawoo.chessbox.bean;

public class ErrorTypeBean {

    /**
     * Id : 1
     * FeedContent : 所有游戏都不可以进入
     */

    private int Id;
    private String FeedContent;

    public int getId() {
        return Id;
    }

    public void setId(int Id) {
        this.Id = Id;
    }

    public String getFeedContent() {
        return FeedContent;
    }

    public void setFeedContent(String FeedContent) {
        this.FeedContent = FeedContent;
    }
}
