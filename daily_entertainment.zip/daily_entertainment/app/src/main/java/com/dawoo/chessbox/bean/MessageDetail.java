package com.dawoo.chessbox.bean;

/**
 * Created by benson on 18-1-17.
 */

public class MessageDetail {
    /**
     * id : null
     * title : null
     * link : null
     * gameName : null
     * publishTime : 1515920956602
     * context : <p>gggggggggggg我们的手机投注平台面向全网玩家，提供近百款老虎机·百家乐·以及彩票游戏投注，线上存款及线上取款，一键操作，运用3D即时运算创造真实场景结合立体影像，完整规划的跨系统娱乐平台，整合同步账号和资料传输，达到随时随地不间断娱乐的享受概念。|ddddddddddddddddddddddd</p>
     */

    private Object id;
    private String title;
    private Object link;
    private Object gameName;
    private long publishTime;
    private String context;
    private String content;

    public Object getId() {
        return id;
    }

    public void setId(Object id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Object getLink() {
        return link;
    }

    public void setLink(Object link) {
        this.link = link;
    }

    public Object getGameName() {
        return gameName;
    }

    public void setGameName(Object gameName) {
        this.gameName = gameName;
    }

    public long getPublishTime() {
        return publishTime;
    }

    public void setPublishTime(long publishTime) {
        this.publishTime = publishTime;
    }

    public String getContext() {
        return context;
    }

    public void setContext(String context) {
        this.context = context;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
