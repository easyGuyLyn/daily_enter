package com.dawoo.chessbox.bean;

/**
 * Created by alex on 18-3-27.
 */

public class SmsBean {
}
