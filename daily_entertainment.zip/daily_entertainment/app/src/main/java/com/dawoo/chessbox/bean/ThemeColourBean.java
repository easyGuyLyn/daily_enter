package com.dawoo.chessbox.bean;

public class ThemeColourBean {

    /**
     * "category0":"#5765CC",
     * "category1":"#5765CC",
     * "category2":"#5765CC",
     * "category3":"#5765CC"
     */
    public String category0;
    public String category1;
    public String category2;
    public String category3;
}
