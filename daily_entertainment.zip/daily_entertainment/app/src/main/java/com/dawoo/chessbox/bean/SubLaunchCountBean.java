package com.dawoo.chessbox.bean;

public class SubLaunchCountBean {

    private String gamecode;

    public SubLaunchCountBean(String s){
        gamecode = s;
    }

    public String getGamecode() {
        return gamecode;
    }

    public void setGamecode(String gamecode) {
        this.gamecode = gamecode;
    }
}
