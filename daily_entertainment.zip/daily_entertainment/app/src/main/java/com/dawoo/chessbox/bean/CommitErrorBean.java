package com.dawoo.chessbox.bean;

public class CommitErrorBean {
    private int content;

    private String more;

    public CommitErrorBean(int content,String more){
        this.content = content;
        this.more = more;
    }
}
