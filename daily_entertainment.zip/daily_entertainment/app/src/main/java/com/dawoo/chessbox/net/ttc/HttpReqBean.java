package com.dawoo.chessbox.net.ttc;

import com.dawoo.chessbox.util.DeviceUtils;
import com.dawoo.chessbox.util.FastJsonUtils;

import java.io.Serializable;

/**
 */

public class HttpReqBean<T> implements Serializable {

    private int ClientSource;
    private long Date;
    private String Sign;
    private T Param;
    private String Token;


    public HttpReqBean(T param, String token) {
        ClientSource = 0;
        Date = System.currentTimeMillis();
        Token = token;
        Param = param;
        Sign = DeviceUtils.md5("2020fadacai" + Date + ClientSource + FastJsonUtils.toJSONString(param));
    }


    public int getClientSource() {
        return ClientSource;
    }

    public void setClientSource(int clientSource) {
        ClientSource = clientSource;
    }

    public long getDate() {
        return Date;
    }

    public void setDate(long date) {
        Date = date;
    }

    public String getSign() {
        return Sign;
    }

    public void setSign(String sign) {
        Sign = sign;
    }

    public T getParam() {
        return Param;
    }

    public void setParam(T param) {
        Param = param;
    }

    public String getToken() {
        return Token;
    }

    public void setToken(String token) {
        Token = token;
    }
}