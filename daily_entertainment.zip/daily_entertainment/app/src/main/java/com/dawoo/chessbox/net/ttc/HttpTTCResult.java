package com.dawoo.chessbox.net.ttc;

import java.io.Serializable;

/**
 * Created by benson on 17-12-20.
 */

public class HttpTTCResult<T> implements Serializable {
//    [{
//        "success":"",	 --->是否成功
//        "Code":"",	 --->状态码
//        "message":"",    --->消息框
//        "version":"", --->版本信息
//        "Value":[{"key":"value"}],	--->返回数据
//        "is_native" true // 是否跳转h5
//    }]

    private int Code;
    private T Value;
    private Long Date;
    private String Token;
    private String Message;

    public int getCode() {
        return Code;
    }

    public void setCode(int code) {
        Code = code;
    }

    public T getValue() {
        return Value;
    }

    public void setValue(T value) {
        Value = value;
    }

    public Long getDate() {
        return Date;
    }

    public void setDate(Long date) {
        Date = date;
    }

    public String getToken() {
        return Token;
    }

    public void setToken(String token) {
        Token = token;
    }

    public String getMessage() {
        return Message;
    }

    public void setMessage(String message) {
        Message = message;
    }
}