package com.dawoo.chessbox.bean;

/**
 * Created by benson on 18-2-28.
 */

public class UrlBean {
    /**
     * gameMsg : 暂时无法登录游戏！
     * gameLink : null
     */

    private String gameMsg;
    private String gameLink;

    public String getGameMsg() {
        return gameMsg;
    }

    public void setGameMsg(String gameMsg) {
        this.gameMsg = gameMsg;
    }

    public String getGameLink() {
        return gameLink;
    }

    public void setGameLink(String gameLink) {
        this.gameLink = gameLink;
    }
}
