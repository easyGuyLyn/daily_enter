package com.dawoo.chessbox.util;

//生成游戏数据

import com.dawoo.chessbox.R;
import com.dawoo.chessbox.bean.ttc.user.rep.GameBean;

import java.util.ArrayList;
import java.util.List;

public class LocalDataUtil {
    public static List<GameBean> getFreeGames(){
        List<GameBean> gameBeans = new ArrayList<>();

        GameBean gameBean8 = new GameBean();
        gameBean8.setIsLocalData(true);
        gameBean8.setGameName("看四张抢庄牛");
        gameBean8.setLocalLogo(R.mipmap.icon_kszqzn);
        gameBean8.setGameLogo("http://img.mvylfne.cn/lc_logo/200/890.png");
        gameBean8.setGameCode("890");
        gameBean8.setLocalLink("http://lc.nwg198.com/");
        gameBeans.add(gameBean8);

        GameBean gameBean10 = new GameBean();
        gameBean10.setIsLocalData(true);
        gameBean10.setGameName("抢庄牛牛");
        gameBean10.setLocalLogo(R.mipmap.icon_qznn);
        gameBean10.setGameLogo("http://img.mvylfne.cn/lc_logo/200/830.png");
        gameBean10.setGameCode("830");
        gameBean10.setLocalLink("http://lc.nwg198.com/");
        gameBeans.add(gameBean10);

        GameBean gameBean5 = new GameBean();
        gameBean5.setIsLocalData(true);
        gameBean5.setGameName("看牌点子牛");
        gameBean5.setLocalLogo(R.mipmap.icon_kpdzn);
        gameBean5.setGameLogo("http://img.mvylfne.cn/lc_logo/200/8100.png");
        gameBean5.setGameCode("8100");
        gameBean5.setLocalLink("http://lc.nwg198.com/");
        gameBeans.add(gameBean5);

        GameBean gameBean7 = new GameBean();
        gameBean7.setIsLocalData(true);
        gameBean7.setGameName("炸金花");
        gameBean7.setLocalLogo(R.mipmap.icon_zjh);
        gameBean7.setGameLogo("http://img.mvylfne.cn/lc_logo/200/220.png");
        gameBean7.setGameCode("220");
        gameBean7.setLocalLink("http://lc.nwg198.com/");
        gameBeans.add(gameBean7);

        GameBean gameBean6 = new GameBean();
        gameBean6.setIsLocalData(true);
        gameBean6.setGameName("斗地主");
        gameBean6.setLocalLogo(R.mipmap.icon_ddz);
        gameBean6.setGameLogo("http://img.mvylfne.cn/lc_logo/200/610.png");
        gameBean6.setGameCode("610");
        gameBean6.setLocalLink("http://lc.nwg198.com/");
        gameBeans.add(gameBean6);

        GameBean gameBean4 = new GameBean();
        gameBean4.setIsLocalData(true);
        gameBean4.setGameName("极光炮捕鱼");
        gameBean4.setLocalLogo(R.mipmap.icon_jgpby);
        gameBean4.setGameLogo("http://img.mvylfne.cn/lc_logo/200/510.png");
        gameBean4.setGameCode("510");
        gameBean4.setLocalLink("http://lc.nwg198.com/");
        gameBeans.add(gameBean4);

        GameBean gameBean = new GameBean();
        gameBean.setIsLocalData(true);
        gameBean.setGameName("21点");
        gameBean.setLocalLogo(R.mipmap.icon_eydian);
        gameBean4.setGameCode("600");
        gameBean.setLocalLink("http://lc.nwg198.com/");
        gameBean.setHot(false);
        gameBeans.add(gameBean);

        GameBean gameBean2 = new GameBean();
        gameBean2.setIsLocalData(true);
        gameBean2.setGameName("百家乐");
        gameBean2.setLocalLogo(R.mipmap.icon_bjl);
        gameBean2.setGameLogo("http://img.mvylfne.cn/lc_logo/200/910.png");
        gameBean2.setGameCode("910");
        gameBean2.setLocalLink("http://lc.nwg198.com/");
        gameBeans.add(gameBean2);

        GameBean gameBean9 = new GameBean();
        gameBean9.setIsLocalData(true);
        gameBean9.setGameName("龙虎斗");
        gameBean9.setLocalLogo(R.mipmap.icon_lhd);
        gameBean9.setGameLogo("http://img.mvylfne.cn/lc_logo/200/900.png");
        gameBean9.setGameCode("900");
        gameBean9.setLocalLink("http://lc.nwg198.com/");
        gameBeans.add(gameBean9);

        GameBean gameBean3 = new GameBean();
        gameBean3.setIsLocalData(true);
        gameBean3.setGameName("百人骰宝");
        gameBean3.setLocalLogo(R.mipmap.icon_brsb);
        gameBean3.setGameLogo("http://img.mvylfne.cn/lc_logo/200/8200.png");
        gameBean3.setGameCode("8200");
        gameBean3.setLocalLink("http://lc.nwg198.com/");
        gameBeans.add(gameBean3);

        GameBean gameBean11 = new GameBean();
        gameBean11.setIsLocalData(true);
        gameBean11.setGameName("德州扑克");
        gameBean11.setLocalLogo(R.mipmap.icon_dzpk);
        gameBean11.setGameLogo("http://img.mvylfne.cn/lc_logo/200/620.png");
        gameBean11.setGameCode("620");
        gameBean11.setLocalLink("http://lc.nwg198.com/");
        gameBeans.add(gameBean11);

        GameBean gameBean12 = new GameBean();
        gameBean12.setIsLocalData(true);
        gameBean12.setGameName("二八杠");
        gameBean12.setLocalLogo(R.mipmap.icon_ebg);
        gameBean12.setGameLogo("http://img.mvylfne.cn/lc_logo/200/720.png");
        gameBean12.setGameCode("720");
        gameBean12.setLocalLink("http://lc.nwg198.com/");
        gameBeans.add(gameBean12);

        GameBean gameBean13 = new GameBean();
        gameBean13.setIsLocalData(true);
        gameBean13.setGameName("抢庄牌九");
        gameBean13.setLocalLogo(R.mipmap.icon_qzpj);
        gameBean13.setGameLogo("http://img.mvylfne.cn/lc_logo/200/730.png");
        gameBean13.setGameCode("730");
        gameBean13.setLocalLink("http://lc.nwg198.com/");
        gameBeans.add(gameBean13);

        GameBean gameBean14 = new GameBean();
        gameBean14.setIsLocalData(true);
        gameBean14.setGameName("三公");
        gameBean14.setLocalLogo(R.mipmap.icon_sg);
        gameBean14.setGameLogo("http://img.mvylfne.cn/lc_logo/200/860.png");
        gameBean14.setGameCode("860");
        gameBean14.setLocalLink("http://lc.nwg198.com/");
        gameBeans.add(gameBean14);

        GameBean gameBean15 = new GameBean();
        gameBean15.setIsLocalData(true);
        gameBean15.setGameName("抢庄二十一点");
        gameBean15.setLocalLogo(R.mipmap.icon_qzesyd);
        gameBean15.setGameLogo("http://img.mvylfne.cn/lc_logo/200/8300.png");
        gameBean15.setGameCode("8300");
        gameBean15.setLocalLink("http://lc.nwg198.com/");
        gameBeans.add(gameBean15);

        GameBean gameBean16 = new GameBean();
        gameBean16.setIsLocalData(true);
        gameBean16.setGameName("红黑大战");
        gameBean16.setLocalLogo(R.mipmap.icon_hhdz);
        gameBean16.setGameLogo("http://img.mvylfne.cn/lc_logo/200/950.png");
        gameBean16.setGameCode("950.png");
        gameBean16.setLocalLink("http://lc.nwg198.com/");
        gameBeans.add(gameBean16);

        GameBean gameBean17 = new GameBean();
        gameBean17.setIsLocalData(true);
        gameBean17.setGameName("十点半");
        gameBean17.setLocalLogo(R.mipmap.icon_sdb);
        gameBean17.setGameLogo("http://img.mvylfne.cn/lc_logo/200/8250.png");
        gameBean17.setGameCode("8250");
        gameBean17.setLocalLink("http://lc.nwg198.com/");
        gameBeans.add(gameBean17);

        GameBean gameBean18 = new GameBean();
        gameBean18.setIsLocalData(true);
        gameBean18.setGameName("疯狂6张牛牛");
        gameBean18.setLocalLogo(R.mipmap.icon_fklznn);
        gameBean18.setGameLogo("http://img.mvylfne.cn/lc_logo/200/8270.png");
        gameBean18.setGameCode("8270");
        gameBean18.setLocalLink("http://lc.nwg198.com/");
        gameBeans.add(gameBean18);

        GameBean gameBean19 = new GameBean();
        gameBean19.setIsLocalData(true);
        gameBean19.setGameName("看牌抢庄三公");
        gameBean19.setLocalLogo(R.mipmap.icon_kpqzsg);
        gameBean19.setGameLogo("http://img.mvylfne.cn/lc_logo/200/8400.png");
        gameBean19.setGameCode("8400");
        gameBean19.setLocalLink("http://lc.nwg198.com/");
        gameBeans.add(gameBean19);

        GameBean gameBean20 = new GameBean();
        gameBean20.setIsLocalData(true);
        gameBean20.setGameName("3+2炸金花");
        gameBean20.setLocalLogo(R.mipmap.icon_zjh32);
        gameBean20.setGameLogo("http://img.mvylfne.cn/lc_logo/200/8240.png");
        gameBean20.setGameCode("8240");
        gameBean20.setLocalLink("http://lc.nwg198.com/");
        gameBeans.add(gameBean20);

        GameBean gameBean21 = new GameBean();
        gameBean21.setIsLocalData(true);
        gameBean21.setGameName("十三水");
        gameBean21.setLocalLogo(R.mipmap.icon_sss);
        gameBean21.setGameLogo("http://img.mvylfne.cn/lc_logo/200/630.png");
        gameBean21.setGameCode("630");
        gameBean21.setLocalLink("http://lc.nwg198.com/");
        gameBeans.add(gameBean21);

        GameBean gameBean22 = new GameBean();
        gameBean22.setIsLocalData(true);
        gameBean22.setGameName("百人牛牛");
        gameBean22.setLocalLogo(R.mipmap.icon_brnn);
        gameBean22.setGameLogo("http://img.mvylfne.cn/lc_logo/200/930.png");
        gameBean22.setGameCode("930");
        gameBean22.setLocalLink("http://lc.nwg198.com/");
        gameBeans.add(gameBean22);

        GameBean gameBean23 = new GameBean();
        gameBean23.setIsLocalData(true);
        gameBean23.setGameName("抢庄五选三");
        gameBean23.setLocalLogo(R.mipmap.icon_qzwxs);
        gameBean23.setGameLogo("http://img.mvylfne.cn/lc_logo/200/990.png");
        gameBean23.setGameCode("990");
        gameBean23.setLocalLink("http://lc.nwg198.com/");
        gameBeans.add(gameBean23);

        GameBean gameBean24 = new GameBean();
        gameBean24.setIsLocalData(true);
        gameBean24.setGameName("通比牛牛");
        gameBean24.setLocalLogo(R.mipmap.icon_tbnn);
        gameBean24.setGameLogo("http://img.mvylfne.cn/lc_logo/200/870.png");
        gameBean24.setGameCode("870");
        gameBean24.setLocalLink("http://lc.nwg198.com/");
        gameBeans.add(gameBean24);

        GameBean gameBean25 = new GameBean();
        gameBean25.setIsLocalData(true);
        gameBean25.setGameName("欢乐斗牛");
        gameBean25.setLocalLogo(R.mipmap.icon_hldn);
        gameBean25.setGameLogo("http://img.mvylfne.cn/lc_logo/200/8500.png");
        gameBean25.setGameCode("8500");
        gameBean25.setLocalLink("http://lc.nwg198.com/");
        gameBeans.add(gameBean25);

        GameBean gameBean26 = new GameBean();
        gameBean26.setIsLocalData(true);
        gameBean26.setGameName("跑得快");
        gameBean26.setLocalLogo(R.mipmap.icon_pdk);
        gameBean26.setGameLogo("http://img.mvylfne.cn/lc_logo/200/640.png");
        gameBean26.setGameCode("640");
        gameBean26.setLocalLink("http://lc.nwg198.com/");
        gameBeans.add(gameBean26);

        GameBean gameBean27 = new GameBean();
        gameBean27.setIsLocalData(true);
        gameBean27.setGameName("抢红包");
        gameBean27.setLocalLogo(R.mipmap.icon_clhb);
        gameBean27.setGameLogo("http://img.mvylfne.cn/lc_logo/200/8260.png");
        gameBean27.setGameCode("8260");
        gameBean27.setLocalLink("http://lc.nwg198.com/");
        gameBeans.add(gameBean27);

        GameBean gameBean28 = new GameBean();
        gameBean28.setIsLocalData(true);
        gameBean28.setGameName("幸运水果机");
        gameBean28.setLocalLogo(R.mipmap.icon_xysgj);
        gameBean28.setGameLogo("http://img.mvylfne.cn/lc_logo/200/8280.png");
        gameBean28.setGameCode("8280");
        gameBean28.setLocalLink("http://lc.nwg198.com/");
        gameBeans.add(gameBean28);

        GameBean gameBean29 = new GameBean();
        gameBean29.setIsLocalData(true);
        gameBean29.setGameName("二人麻将");
        gameBean19.setGameLogo("http://img.mvylfne.cn/lc_logo/200/740.png");
        gameBean19.setGameCode("740");
        gameBean29.setLocalLogo(R.mipmap.icon_ermj);
        gameBean29.setLocalLink("http://lc.nwg198.com/");
        gameBeans.add(gameBean29);

//        GameBean gameBean30 = new GameBean();
//        gameBean30.setIsLocalData(true);
//        gameBean30.setGameName("百得之");
//        gameBean30.setLocalLogo(R.mipmap.icon_brsb);
//        gameBean30.setLocalLink("http://lc.nwg198.com/");
//        gameBeans.add(gameBean30);

        return gameBeans;
    }

    public static List<GameBean> getMjDz(){
        List<GameBean> gameBeans = new ArrayList<>();
        GameBean gameBean = new GameBean();
        gameBean.setIsLocalData(true);
        gameBean.setGameName("天天斗地主");
        gameBean.setLocalLogo(R.mipmap.icon_ttddz);
        gameBean.setLocalLink("http://res.12317wan.com/gameModule/h5/jsddz/365you/201908142110/index.html");
        gameBeans.add(gameBean);

        GameBean gameBean2 = new GameBean();
        gameBean2.setIsLocalData(true);
        gameBean2.setGameName("指尖跑得快");
        gameBean2.setLocalLogo(R.mipmap.icon_zjpdk);
        gameBean2.setLocalLink("http://wechatres.12317wan.com/qipai/gameModule/h5/pdk/365you/package/109091/index.html");
        gameBeans.add(gameBean2);

        GameBean gameBean3 = new GameBean();
        gameBean3.setIsLocalData(true);
        gameBean3.setGameName("四川麻将");
        gameBean3.setLocalLogo(R.mipmap.icon_scmj);
        gameBean3.setLocalLink("http://res.12317wan.com/gameModule/h5/mjhj/365you/package/601031/SCMJXZDD/");
        gameBeans.add(gameBean3);

        GameBean gameBean4 = new GameBean();
        gameBean4.setIsLocalData(true);
        gameBean4.setGameName("广东麻将");
        gameBean4.setLocalLogo(R.mipmap.icon_gdmj);
        gameBean4.setLocalLink("http://res.12317wan.com/gameModule/h5/mjhj/365you/package/601031/ZJGDMJ/");
        gameBeans.add(gameBean4);

        GameBean gameBean5 = new GameBean();
        gameBean5.setIsLocalData(true);
        gameBean5.setGameName("长沙麻将");
        gameBean5.setLocalLogo(R.mipmap.icon_csmj);
        gameBean5.setLocalLink("http://res.12317wan.com/gameModule/h5/mjhj/365you/package/601031/ZJCSMJ/");
        gameBeans.add(gameBean5);

        GameBean gameBean6 = new GameBean();
        gameBean6.setIsLocalData(true);
        gameBean6.setGameName("湖北麻将");
        gameBean6.setLocalLogo(R.mipmap.icon_hbmj);
        gameBean6.setLocalLink("http://res.12317wan.com/gameModule/h5/mjhj/365you/package/601031/ZJHBMJ/");
        gameBeans.add(gameBean6);

        GameBean gameBean7 = new GameBean();
        gameBean7.setIsLocalData(true);
        gameBean7.setGameName("贵州麻将");
        gameBean7.setLocalLogo(R.mipmap.icon_gzmj);
        gameBean7.setLocalLink("http://res.12317wan.com/gameModule/h5/mjhj/365you/package/601031/GZZJMJ/");
        gameBeans.add(gameBean7);
        return gameBeans;
    }

    public static List<GameBean> getSport(){
        List<GameBean> gameBeans = new ArrayList<>();
        GameBean gameBean = new GameBean();
        gameBean.setIsLocalData(true);
        gameBean.setGameName("凤凰体育");
        gameBean.setLocalLogo(R.mipmap.icon_fhtiyu);
        gameBean.setLocalLink("https://www.fhty86.com/app/home/entry/register/?i_code=7524811");
        gameBean.setIsVerticalScreen(true);
        gameBeans.add(gameBean);
        return gameBeans;
    }
}
