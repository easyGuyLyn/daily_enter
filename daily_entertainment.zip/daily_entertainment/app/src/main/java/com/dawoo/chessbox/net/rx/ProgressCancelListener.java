package com.dawoo.chessbox.net.rx;

public interface ProgressCancelListener {
    void onCancelProgress();
}
