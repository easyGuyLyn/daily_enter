package com.dawoo.chessbox.net;

/**
 * Created by benson on 17-12-20.
 */

public class HttpResult<T> {
//    [{
//        "success":"",	 --->是否成功
//        "Code":"",	 --->状态码
//        "message":"",    --->消息框
//        "version":"", --->版本信息
//        "Value":[{"key":"value"}],	--->返回数据
//        "is_native" true // 是否跳转h5
//    }]

    private boolean success;
    private int Code;
    private String message;
    private String version;
    private T Value;


    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public int getCode() {
        return Code;
    }

    public void setCode(int code) {
        this.Code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public T getValue() {
        return Value;
    }

    public void setValue(T value) {
        this.Value = value;
    }

}