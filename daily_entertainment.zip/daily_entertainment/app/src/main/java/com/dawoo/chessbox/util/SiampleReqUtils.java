package com.dawoo.chessbox.util;

import com.dawoo.chessbox.BoxApplication;
import com.dawoo.chessbox.bean.DataCenter;
import com.dawoo.chessbox.bean.ttc.user.rep.PayBean;
import com.dawoo.chessbox.net.ttc.HttpReqBean;
import com.dawoo.chessbox.net.ttc.HttpTTCResult;
import com.dawoo.pushsdk.util.GsonUtil;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.zhy.http.okhttp.OkHttpUtils;


import okhttp3.Call;
import okhttp3.MediaType;
import okhttp3.Response;

import static com.dawoo.chessbox.util.AutoLogin.CheckHasMainEnanceError;

public class SiampleReqUtils {


    public static void startApp() {

        String url = DataCenter.getInstance().getIp() + "/api/User/StartApp";

        String jsonParam = GsonUtil.GsonString(new HttpReqBean("", DataCenter.getInstance().getCookie()));

        OkHttpUtils
                .postString()
                .url(url)
                .content(jsonParam)
                .mediaType(MediaType.parse("application/json; charset=utf-8"))
                .build()
                .execute(new com.zhy.http.okhttp.callback.Callback() {
                    @Override
                    public Object parseNetworkResponse(Response response, int id) throws Exception {

                        if (!CheckHasMainEnanceError(response)) {
                            return null;
                        }

                        if (response.code() != 200) {
                            //   SingleToast.showMsg("网络错误码 " + response.code());
                            return null;
                        }

                        String json = response.body().string();

                        Gson gson = new Gson();
                        HttpTTCResult<Object> responseResult2 = gson.fromJson(json,
                                new TypeToken<HttpTTCResult<Object>>() {
                                }.getType());

                        if (responseResult2.getCode() == 1) {

                            DataCenter.getInstance().setCookie(responseResult2.getToken());
                            DataCenter.getInstance().saveUserCache();

                        }
                        return null;
                    }

                    @Override
                    public void onError(Call call, Exception e, int id) {
                    }

                    @Override
                    public void onResponse(Object response, int id) {
                    }

                });


    }


}
