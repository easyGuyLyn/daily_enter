package com.dawoo.chessbox.bean;

import java.util.List;

/**
 * Created by benson on 18-1-15.
 */

public class SysNotice {
    /**
     * list : [{"id":null,"content":"water","publishTime":1515932468595,"link":"/mineOrigin/getSysNoticeDetail.html?searchId=31a7389e9d8c4196511ea8233b0303f6","title":null,"read":false,"searchId":"31a7389e9d8c4196511ea8233b0303f6"},{"id":null,"content":"测试","publishTime":1515922980573,"link":"/mineOrigin/getSysNoticeDetail.html?searchId=0bd29d5e6d088a28c6e0a82c9bec48be","title":null,"read":false,"searchId":"0bd29d5e6d088a28c6e0a82c9bec48be"},{"id":null,"content":"我们的手机投注平台面向全网玩家，提供近百款老虎机·百家乐·以及彩票游戏投注，线上存款及线上取款，一键...","publishTime":1515922957248,"link":"/mineOrigin/getSysNoticeDetail.html?searchId=ba92b7f16aafd03a6cb2a5a01ccd3d68","title":null,"read":false,"searchId":"ba92b7f16aafd03a6cb2a5a01ccd3d68"},{"id":null,"content":"aaabbbbbbbbbbbbbbbbbb","publishTime":1515922907846,"link":"/mineOrigin/getSysNoticeDetail.html?searchId=6e2a4df426d89dc1678960453367cd12","title":null,"read":false,"searchId":"6e2a4df426d89dc1678960453367cd12"},{"id":null,"content":"aaaaaaaaaaaaaaaaaaaaaaaaaa","publishTime":1515920922657,"link":"/mineOrigin/getSysNoticeDetail.html?searchId=eee2ed8fd2d41ac4bb79fce90081e59e","title":null,"read":false,"searchId":"eee2ed8fd2d41ac4bb79fce90081e59e"},{"id":null,"content":"发发发","publishTime":1515297351309,"link":"/mineOrigin/getSysNoticeDetail.html?searchId=6ca86a89cdac9468322fe7d8ccdc61fe","title":null,"read":false,"searchId":"6ca86a89cdac9468322fe7d8ccdc61fe"},{"id":null,"content":"是是是","publishTime":1515297326902,"link":"/mineOrigin/getSysNoticeDetail.html?searchId=223dccb9361e416278720da9daa4d24b","title":null,"read":false,"searchId":"223dccb9361e416278720da9daa4d24b"},{"id":null,"content":"11.03","publishTime":1515294180000,"link":"/mineOrigin/getSysNoticeDetail.html?searchId=81533d6c711948a219773c91794b2893","title":null,"read":false,"searchId":"81533d6c711948a219773c91794b2893"},{"id":null,"content":"我的了歌A我的了歌B我的了歌A我的了歌B我的了歌A我的了歌B我的了歌A我的了歌B我的了歌A我的了歌B...","publishTime":1515291947990,"link":"/mineOrigin/getSysNoticeDetail.html?searchId=844ab9b7da1f116c4f60f37d9046eaba","title":null,"read":false,"searchId":"844ab9b7da1f116c4f60f37d9046eaba"},{"id":null,"content":"water testr","publishTime":1514463244391,"link":"/mineOrigin/getSysNoticeDetail.html?searchId=7f5dbe829589786bceabb7b0a4953e4e","title":null,"read":false,"searchId":"7f5dbe829589786bceabb7b0a4953e4e"},{"id":null,"content":"kkk","publishTime":1514120967797,"link":"/mineOrigin/getSysNoticeDetail.html?searchId=89702a94556fab7c7c3b7a312ecae193","title":null,"read":false,"searchId":"89702a94556fab7c7c3b7a312ecae193"},{"id":null,"content":"qqqqqq","publishTime":1514083503592,"link":"/mineOrigin/getSysNoticeDetail.html?searchId=492bfb90b1e275269e4d023c9c59dda4","title":null,"read":false,"searchId":"492bfb90b1e275269e4d023c9c59dda4"},{"id":null,"content":"AAAAAA","publishTime":1513862299950,"link":"/mineOrigin/getSysNoticeDetail.html?searchId=c5901cd663453a492a8d375df07e4613","title":null,"read":false,"searchId":"c5901cd663453a492a8d375df07e4613"},{"id":null,"content":"  一剑泯恩仇","publishTime":1513860580589,"link":"/mineOrigin/getSysNoticeDetail.html?searchId=2b689e3f0475dc00e7ec7c636aee9503","title":null,"read":false,"searchId":"2b689e3f0475dc00e7ec7c636aee9503"},{"id":null,"content":"二十年的手速","publishTime":1513860208915,"link":"/mineOrigin/getSysNoticeDetail.html?searchId=0e0cee3d0572d7b44ab6f073047745ce","title":null,"read":false,"searchId":"0e0cee3d0572d7b44ab6f073047745ce"},{"id":null,"content":"系统公告1","publishTime":1513859585250,"link":"/mineOrigin/getSysNoticeDetail.html?searchId=b1e3e60ef5b0da56aaef733e18aacb38","title":null,"read":false,"searchId":"b1e3e60ef5b0da56aaef733e18aacb38"},{"id":null,"content":"系统公告","publishTime":1513859572185,"link":"/mineOrigin/getSysNoticeDetail.html?searchId=32d9719c544803a144fe8ae029eabbdf","title":null,"read":false,"searchId":"32d9719c544803a144fe8ae029eabbdf"},{"id":null,"content":"啊啊啊","publishTime":1513858936603,"link":"/mineOrigin/getSysNoticeDetail.html?searchId=de1bec268383cc4c5e31873844109f67","title":null,"read":false,"searchId":"de1bec268383cc4c5e31873844109f67"},{"id":null,"content":"003","publishTime":1513858865445,"link":"/mineOrigin/getSysNoticeDetail.html?searchId=6bb80e38602f797920d749a8b475d97c","title":null,"read":false,"searchId":"6bb80e38602f797920d749a8b475d97c"},{"id":null,"content":"系统公告    12.21.    20.15","publishTime":1513858548673,"link":"/mineOrigin/getSysNoticeDetail.html?searchId=f2403ff9a20a3b1994f437162c2963e5","title":null,"read":false,"searchId":"f2403ff9a20a3b1994f437162c2963e5"}]
     * pageTotal : 22
     * minDate : 1513440000000
     * maxDate : 1516000614228
     */

    private int pageTotal;
    private long minDate;
    private long maxDate;
    private List<ListBean> list;

    public int getPageTotal() {
        return pageTotal;
    }

    public void setPageTotal(int pageTotal) {
        this.pageTotal = pageTotal;
    }

    public long getMinDate() {
        return minDate;
    }

    public void setMinDate(long minDate) {
        this.minDate = minDate;
    }

    public long getMaxDate() {
        return maxDate;
    }

    public void setMaxDate(long maxDate) {
        this.maxDate = maxDate;
    }

    public List<ListBean> getList() {
        return list;
    }

    public void setList(List<ListBean> list) {
        this.list = list;
    }

    public static class ListBean {
        /**
         * id : null
         * content : water
         * publishTime : 1515932468595
         * link : /mineOrigin/getSysNoticeDetail.html?searchId=31a7389e9d8c4196511ea8233b0303f6
         * title : null
         * read : false
         * searchId : 31a7389e9d8c4196511ea8233b0303f6
         */

        private Object id;
        private String content;
        private long publishTime;
        private String link;
        private Object title;
        private boolean read;
        private String searchId;

        public Object getId() {
            return id;
        }

        public void setId(Object id) {
            this.id = id;
        }

        public String getContent() {
            return content;
        }

        public void setContent(String content) {
            this.content = content;
        }

        public long getPublishTime() {
            return publishTime;
        }

        public void setPublishTime(long publishTime) {
            this.publishTime = publishTime;
        }

        public String getLink() {
            return link;
        }

        public void setLink(String link) {
            this.link = link;
        }

        public Object getTitle() {
            return title;
        }

        public void setTitle(Object title) {
            this.title = title;
        }

        public boolean isRead() {
            return read;
        }

        public void setRead(boolean read) {
            this.read = read;
        }

        public String getSearchId() {
            return searchId;
        }

        public void setSearchId(String searchId) {
            this.searchId = searchId;
        }
    }
}
