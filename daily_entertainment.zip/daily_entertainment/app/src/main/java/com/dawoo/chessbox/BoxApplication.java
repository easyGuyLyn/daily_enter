package com.dawoo.chessbox;

import android.app.Application;
import android.content.Context;
import android.os.Handler;
import android.support.multidex.MultiDex;
import android.util.Log;

import com.dawoo.chessbox.bean.DataCenter;
import com.dawoo.chessbox.net.TlsSniSocketFactory;
import com.dawoo.chessbox.net.TrueHostnameVerifier;
import com.dawoo.chessbox.util.ActivityUtil;
import com.dawoo.chessbox.util.BackGroundUtil;
import com.dawoo.chessbox.util.SSLUtil;
import com.dawoo.chessbox.util.SoundUtil;
import com.squareup.leakcanary.LeakCanary;
import com.tencent.smtt.sdk.QbSdk;
import com.umeng.commonsdk.UMConfigure;
import com.umeng.message.IUmengRegisterCallback;
import com.umeng.message.PushAgent;
import com.zhy.http.okhttp.OkHttpUtils;

import java.util.concurrent.TimeUnit;

import cn.jpush.android.api.JPushInterface;
import kit.umentshare.UMShareLoginHelper;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;

import static com.dawoo.chessbox.net.RetrofitHelper.DEFAULT_READ_TIMEOUT_SECONDS;
import static com.dawoo.chessbox.net.RetrofitHelper.DEFAULT_TIMEOUT_SECONDS;
import static com.dawoo.chessbox.net.RetrofitHelper.DEFAULT_WRITE_TIMEOUT_SECONDS;

/**
 * Created by benson on 17-12-27.
 */

public class BoxApplication extends Application {
    private static Context context;
    public static Handler handler = new Handler();

    //兼容 4.5版本以下 添加MultiDex分包，但未初始化的问题
    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        MultiDex.install(base);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        //不用这个工具库我浑身难受
        if (BuildConfig.DEBUG) {
            if (LeakCanary.isInAnalyzerProcess(this)) {
                // This process is dedicated to LeakCanary for heap analysis.
                // You should not connect your app in this process.
                return;
            }
            LeakCanary.install(this);
        }
        initOkHttpUtils();
        context = getApplicationContext();
        BackGroundUtil.registerActivityLifecycleCallbacks(this);
        if (!BuildConfig.DEBUG) {
            // CrashHandler.getInstance().init();
        }
        DataCenter.getInstance().getSysInfo().initSysInfo(context);
        ActivityUtil.setContext(context);
        // 加载音频
        SoundUtil.getInstance().load();

        loadX5();

        UMShareLoginHelper.init(this);

        //ScreenRotateUtil.getInstance(this).start();

        //   IPCSocketManager.getInstance().startServerService();

        regesterJPush();

        initUm();

        initGiSdk();
    }


    /**
     * 获取全局上下文
     */
    public static Context getContext() {
        return context;
    }

    /**
     * 加载x5
     */
    void loadX5() {
        //搜集本地tbs内核信息并上报服务器，服务器返回结果决定使用哪个内核。

        QbSdk.PreInitCallback cb = new QbSdk.PreInitCallback() {

            @Override
            public void onViewInitFinished(boolean arg0) {
                // TODO Auto-generated method stub
                //x5內核初始化完成的回调，为true表示x5内核加载成功，否则表示x5内核加载失败，会自动切换到系统内核。
                Log.d("loadX5", " onViewInitFinished is " + arg0);
            }

            @Override
            public void onCoreInitFinished() {
                // TODO Auto-generated method stub
            }
        };
        //x5内核初始化接口
        QbSdk.initX5Environment(getApplicationContext(), cb);
    }


    public static void initOkHttpUtils() {

        //   日志拦截器
        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
        if (BuildConfig.DEBUG) {
            interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        } else {
            interceptor.setLevel(HttpLoggingInterceptor.Level.NONE);
        }
        // 添加httplog

        //设置https
        OkHttpClient client = new OkHttpClient.Builder()
                .addInterceptor(interceptor)
                .connectTimeout(DEFAULT_TIMEOUT_SECONDS, TimeUnit.SECONDS)
                .readTimeout(DEFAULT_READ_TIMEOUT_SECONDS, TimeUnit.SECONDS)
                .writeTimeout(DEFAULT_WRITE_TIMEOUT_SECONDS, TimeUnit.SECONDS)
                .retryOnConnectionFailure(true)//失败重连
                .followRedirects(true)
                .sslSocketFactory(new TlsSniSocketFactory(), new SSLUtil.TrustAllManager())
                .hostnameVerifier(new TrueHostnameVerifier())
                .build();
        OkHttpUtils.initClient(client);
    }


    void regesterJPush() {
        if (BuildConfig.DEBUG) {
            JPushInterface.setDebugMode(true);
        }

        JPushInterface.init(this);
    }


    void initUm() {

        //足球圈  最右app
        UMConfigure.init(this, BuildConfig.um_key, getString(R.string.app_code), UMConfigure.DEVICE_TYPE_PHONE,
                BuildConfig.um_push_key);

        UMConfigure.setLogEnabled(true);


        //获取消息推送代理示例
        PushAgent mPushAgent = PushAgent.getInstance(this);
//注册推送服务，每次调用register方法都会回调该接口
        mPushAgent.register(new IUmengRegisterCallback() {
            @Override
            public void onSuccess(String deviceToken) {
                //注册成功会返回deviceToken deviceToken是推送消息的唯一标志
                Log.e("UM", "注册成功：deviceToken：-------->  " + deviceToken);
            }

            @Override
            public void onFailure(String s, String s1) {
                Log.e("UM", "注册失败：-------->  " + "s:" + s + ",s1:" + s1);
            }
        });

    }


    private void initGiSdk() {

//        GInsightManager.getInstance().init(this, new IGInsightEventListener() {
//            @Override
//            public void onSuccess(String giuid) {
//                Log.d("BoxApplication", "init success,  giuid:" + giuid);
//            }
//
//            @Override
//            public void onError(String error) {
//                Log.d("BoxApplication", "init failed, msg:" + error);
//            }
//        });


    }


}
