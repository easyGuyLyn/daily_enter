package com.dawoo.chessbox.bean;

/**
 * Created by benson on 18-1-1.
 */

public class countDrawTimes {
}
