package com.dawoo.pushsdk.callback;

public interface ConnectStatusListener {

    void onConnectStatus(int code, String status);

}

